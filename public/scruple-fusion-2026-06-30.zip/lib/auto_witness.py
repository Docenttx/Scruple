"""Ambient witness timer thread.

Loop: every `interval` seconds, if the document is dirty since last witness,
fire a Fusion custom event that marshals the actual witness call onto the
Fusion API thread.

Probe 5.3 will tell us whether we can call Fusion API directly from a Python
thread or whether marshalling is mandatory. We design for the strict case
(marshalling required) since it works in both worlds.
"""

from __future__ import annotations

import threading
import time
from typing import Any, Callable, Optional

DEFAULT_INTERVAL_SECONDS = 300  # 5 minutes; user-configurable via Settings dialog
CUSTOM_EVENT_TICK = "scruple_witness_tick"


class AutoWitnessThread(threading.Thread):
    def __init__(
        self,
        app: Any,
        is_dirty_callback: Callable[[], bool],
        tick_callback: Callable[[], None],
        interval_seconds: float = DEFAULT_INTERVAL_SECONDS,
    ) -> None:
        super().__init__(daemon=True, name="ScrupleAutoWitness")
        self._app = app
        self._is_dirty = is_dirty_callback
        self._tick = tick_callback
        self._interval = float(interval_seconds)
        self._stop_event = threading.Event()
        self.last_tick_at: Optional[float] = None
        self.ticks_fired = 0

    def run(self) -> None:
        while not self._stop_event.wait(self._interval):
            try:
                if self._is_dirty():
                    self._tick()
                    self.last_tick_at = time.time()
                    self.ticks_fired += 1
            except Exception:
                # Never let an exception kill the daemon thread.
                pass

    def stop(self) -> None:
        self._stop_event.set()


def start(app: Any, ui: Any, palette: Any, *, interval_seconds: float = DEFAULT_INTERVAL_SECONDS) -> AutoWitnessThread:
    """Start the ambient witness loop. Returns the thread for stop()."""
    # Register the custom event the loop will fire; the handler (installed by
    # palette_host on the Fusion API thread) is what actually performs the
    # witness call. Caller is responsible for installing that handler.
    if hasattr(app, "registerCustomEvent"):
        try:
            app.registerCustomEvent(CUSTOM_EVENT_TICK)
        except Exception:
            pass

    def is_dirty() -> bool:
        try:
            return bool(app.activeDocument.design.isDirty)
        except Exception:
            return False

    def tick() -> None:
        try:
            app.fireCustomEvent(CUSTOM_EVENT_TICK)
        except Exception:
            pass

    t = AutoWitnessThread(app, is_dirty, tick, interval_seconds=interval_seconds)
    t.start()
    return t


def stop(t: AutoWitnessThread) -> None:
    t.stop()
    t.join(timeout=2.0)
