"""Mock surface of adsk.core / adsk.fusion just deep enough to test the add-in.

Tests can import these directly; the add-in itself only uses them when the
real adsk modules fail to import (i.e., on Oracle, in CI, in pytest).

The mocks are deliberately minimal — we mimic only the APIs we call. When we
discover we need a new one, we add it here and in the desktop probe list.
"""

from __future__ import annotations

import os
import tempfile
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


# ---------------------------------------------------------------- Attributes

@dataclass
class MockAttribute:
    groupName: str
    name: str
    value: str


class MockAttributes:
    """Mocks `design.attributes` — Fusion's persistent custom-data API.

    Values are strings only in real Fusion; we preserve that constraint here.
    """

    def __init__(self) -> None:
        self._items: List[MockAttribute] = []

    def add(self, group: str, name: str, value: str) -> MockAttribute:
        if not isinstance(value, str):
            raise TypeError(f"Attribute value must be str; got {type(value).__name__}")
        # Replace if exists.
        existing = self.itemByName(group, name)
        if existing is not None:
            existing.value = value
            return existing
        a = MockAttribute(group, name, value)
        self._items.append(a)
        return a

    def itemByName(self, group: str, name: str) -> Optional[MockAttribute]:
        for a in self._items:
            if a.groupName == group and a.name == name:
                return a
        return None

    def itemsByGroup(self, group: str) -> List[MockAttribute]:
        return [a for a in self._items if a.groupName == group]


# ---------------------------------------------------------------- ExportManager

@dataclass
class MockFusionArchiveOptions:
    filename: str
    rootComponent: Any


class MockExportManager:
    """Mocks `design.exportManager`.

    `execute()` writes a fixed test fixture's bytes to the requested path so the
    downstream hash/witness flow gets stable, reproducible input.
    """

    def __init__(self, fixture_path: Optional[str] = None) -> None:
        self.fixture_path = fixture_path
        self.executed: List[MockFusionArchiveOptions] = []

    def createFusionArchiveExportOptions(self, filename: str, rootComponent: Any) -> MockFusionArchiveOptions:
        return MockFusionArchiveOptions(filename=filename, rootComponent=rootComponent)

    def execute(self, opts: MockFusionArchiveOptions) -> bool:
        self.executed.append(opts)
        # Write fixture bytes (or synthesized bytes) to the requested path.
        os.makedirs(os.path.dirname(opts.filename), exist_ok=True)
        if self.fixture_path and os.path.exists(self.fixture_path):
            with open(self.fixture_path, "rb") as src, open(opts.filename, "wb") as dst:
                dst.write(src.read())
        else:
            # Synthesize varying bytes so each export is uniquely hashable.
            payload = f"mock-fusion-archive-{len(self.executed):04d}".encode()
            with open(opts.filename, "wb") as f:
                f.write(payload)
        return True


# ---------------------------------------------------------------- Document/Design

@dataclass
class MockComponent:
    name: str = "Root"


@dataclass
class MockDesign:
    rootComponent: MockComponent = field(default_factory=MockComponent)
    attributes: MockAttributes = field(default_factory=MockAttributes)
    exportManager: MockExportManager = field(default_factory=MockExportManager)
    isDirty: bool = True
    name: str = "Untitled"


@dataclass
class MockDocument:
    design: MockDesign = field(default_factory=MockDesign)
    name: str = "Untitled"
    isSaved: bool = False


# ---------------------------------------------------------------- App + UI

class MockEvent:
    def __init__(self) -> None:
        self.handlers: List[Callable[[Any], None]] = []

    def add(self, handler: Callable[[Any], None]) -> None:
        self.handlers.append(handler)

    def fire(self, args: Any = None) -> None:
        for h in self.handlers:
            h(args)


class MockDocumentEvents:
    def __init__(self) -> None:
        self.documentSaved = MockEvent()
        self.documentOpened = MockEvent()


class MockApp:
    def __init__(self, design: Optional[MockDesign] = None) -> None:
        self.activeDocument = MockDocument(design=design or MockDesign())
        self.documentEvents = MockDocumentEvents()
        self.custom_events: Dict[str, MockEvent] = {}

    def fireCustomEvent(self, name: str, payload: Any = None) -> None:
        ev = self.custom_events.get(name)
        if ev:
            ev.fire(payload)

    def registerCustomEvent(self, name: str) -> MockEvent:
        """Idempotent: return the existing event if already registered.

        Real Fusion raises on duplicate registration — but auto_witness wraps
        the call in try/except expressly for that reason. Returning the same
        event lets tests pre-register a handler before auto_witness.start()
        without losing it.
        """
        ev = self.custom_events.get(name)
        if ev is None:
            ev = MockEvent()
            self.custom_events[name] = ev
        return ev


class MockUI:
    def __init__(self) -> None:
        self.messages: List[str] = []
        self.palettes = MockPalettes()

    def messageBox(self, text: str) -> None:
        self.messages.append(text)


class MockPalette:
    def __init__(self, id: str, name: str, html: str, **kwargs: Any) -> None:
        self.id = id
        self.name = name
        self.htmlFileURL = html
        self.isVisible = kwargs.get("isVisible", True)
        self.sent: List[tuple] = []
        self.deleted = False

    def sendInfoToHTML(self, action: str, payload: str) -> None:
        self.sent.append((action, payload))

    def deleteMe(self) -> None:
        self.deleted = True


class MockPalettes:
    def __init__(self) -> None:
        self._items: Dict[str, MockPalette] = {}

    def add(self, id: str, name: str, htmlFileURL: str, **kwargs: Any) -> MockPalette:
        p = MockPalette(id, name, htmlFileURL, **kwargs)
        self._items[id] = p
        return p

    def itemById(self, id: str) -> Optional[MockPalette]:
        return self._items.get(id)


# ---------------------------------------------------------------- helpers

def make_app_with_fixture(fixture_bytes: Optional[bytes] = None) -> MockApp:
    """Convenience: build a MockApp whose export writes the given bytes (or synth)."""
    design = MockDesign()
    if fixture_bytes is not None:
        # Persist fixture to a tmp file so the ExportManager copies it on execute.
        f = tempfile.NamedTemporaryFile(delete=False, suffix=".f3d")
        f.write(fixture_bytes)
        f.close()
        design.exportManager = MockExportManager(fixture_path=f.name)
    return MockApp(design=design)
