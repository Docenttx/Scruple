"""Lock + payment flow — Python orchestration for the chain-lock action.

The palette UI calls Python via the fusion bridge with `lock_chain` action.
This module:
  1. Hits scruple-web's /api/lock/chain to start the lock flow
  2. If the server returns paymentRequired, the URL-scheme handler opens
     Stripe Checkout in the system browser
  3. Polls /api/projects/<id> until the project transitions to chain_locked
  4. Writes the lock result back to the Fusion document's Attributes

For Oracle-side testing we substitute the user's browser+Stripe step with
the dev test-pay helper (scripts/stripe-test-pay.mjs invoked from Node)
so the entire lock pipeline can run headless against arlocal + the RVN
testnet anchors that already work in the demos.
"""

from __future__ import annotations

import os
import subprocess
import time
from typing import Any, Dict, Optional

from .scruple_client import ScrupleClient, ScrupleClientError
from .witness import write_lock_attributes


def is_already_locked(project: Dict[str, Any]) -> bool:
    status = project.get("status") or project.get("project", {}).get("status")
    return status in {"chain_locked", "persistent_locked", "permanent_locked"}


def poll_until_locked(
    client: ScrupleClient,
    project_id: int,
    *,
    timeout_seconds: int = 180,
    interval_seconds: float = 3.0,
) -> Dict[str, Any]:
    """Poll /api/projects/<id> until status flips to chain_locked.

    Raises TimeoutError if the deadline passes without a transition.
    """
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        state = client.get_project(project_id)
        project = state.get("project") or state
        if is_already_locked(project):
            return state
        time.sleep(interval_seconds)
    raise TimeoutError(f"Project {project_id} did not lock within {timeout_seconds}s")


def run_dev_stripe_pay(
    project_id: int,
    *,
    action: str = "chain-lock-pinned",
    cookie_value: Optional[str] = None,
    scruple_web_root: str = "/data/scruple-web",
) -> str:
    """Headless Stripe sandbox helper for Oracle-side dev runs.

    Invokes scripts/stripe-test-pay.mjs as a subprocess. Returns the
    PaymentIntent ID (pi_xxx) on success. The real desktop flow uses
    Stripe Checkout in the user's browser; this helper is only for
    the test harness.
    """
    env = dict(os.environ)
    if cookie_value:
        env["SCRUPLE_SESSION"] = cookie_value
    cmd = ["node", "scripts/stripe-test-pay.mjs",
           "--action", action, "--project", str(project_id)]
    result = subprocess.run(
        cmd, cwd=scruple_web_root, env=env, capture_output=True, text=True, timeout=120
    )
    if result.returncode != 0:
        raise RuntimeError(
            f"stripe-test-pay failed: stdout={result.stdout!r} stderr={result.stderr!r}"
        )
    # Output contains a line like "PAYMENT_INTENT=pi_3ABC…" — extract any token
    # of shape pi_<alnum>+ from anywhere in the combined output.
    import re
    m = re.search(r"\bpi_[A-Za-z0-9]+", result.stdout + result.stderr)
    if m:
        return m.group(0)
    raise RuntimeError(f"could not parse pi_… from stripe-test-pay output: {result.stdout!r} stderr={result.stderr!r}")


def lock_and_anchor(
    design: Any,
    client: ScrupleClient,
    project_id: int,
    payment_intent_id: str,
    *,
    tier: str = "pinned",
    write_to_attributes: bool = True,
    poll_timeout_seconds: int = 180,
) -> Dict[str, Any]:
    """Submit /api/lock/chain, poll until anchored, write result to Attributes."""
    try:
        resp = client.lock_chain(project_id, payment_intent_id, tier=tier)
    except ScrupleClientError as e:
        raise RuntimeError(f"lock submission failed: {e}; body={e.body}") from None

    # The endpoint returns the lock result inline (synchronous chain anchor).
    # But the response might also indicate async — handle both.
    project_state = resp if resp.get("scrId") else None
    if project_state is None:
        # Async path: poll until locked.
        state = poll_until_locked(client, project_id, timeout_seconds=poll_timeout_seconds)
        project_state = state.get("project") or state

    if write_to_attributes and design is not None:
        write_lock_attributes(design, project_state)
    return project_state
