"""Witness flow: export Fusion design → hash bytes → POST /api/runs.

Pure logic — independent of Fusion's threading model. Caller is responsible
for ensuring `design.exportManager.execute()` happens on the right thread
(Fusion API thread, marshalled via fireCustomEvent if Probe 5.3 demands).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import tempfile
import time
import uuid
from typing import Any, Dict, Optional

from .scruple_client import ScrupleClient, ScrupleClientError

ADDIN_VERSION = "0.1.0"
DEFAULT_FUSION_VERSION = "unknown"  # Probe 5.2 will tell us how to read this from adsk.core.Application


def _sha256_file(path: str, chunk: int = 1024 * 1024) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            buf = f.read(chunk)
            if not buf:
                break
            h.update(buf)
    return h.hexdigest()


def build_machine_manifest(fusion_version: str = DEFAULT_FUSION_VERSION) -> Dict[str, Any]:
    """The machine_manifest_hash gets folded into the canonical leaf preimage.

    For the Fusion add-in this binds: Fusion version + add-in version. Future
    work can bind toolchain (CAM post-processors, simulation plugins) once we
    have a discovery API call for them.
    """
    return {
        "host": "fusion360",
        "fusion_version": fusion_version,
        "addin": "scruple-fusion",
        "addin_version": ADDIN_VERSION,
    }


def build_workflow_api_json(machine_manifest: Dict[str, Any], doc_name: str) -> Dict[str, Any]:
    """The witness server hashes workflow_api_json byte-for-byte. Stable shape.

    For Fusion we use the workflow_api_json field to carry the machine_manifest
    + document name so it lands in the canonical leaf preimage. This is the
    same pattern used by the canvas: every distinct producer carries its
    distinguishing context here.
    """
    return {
        "kind": "fusion_export",
        "machine_manifest": machine_manifest,
        "document_name": doc_name,
    }


def export_and_witness(
    design: Any,
    client: ScrupleClient,
    project_id: int,
    *,
    fusion_version: str = DEFAULT_FUSION_VERSION,
    trigger: str = "manual",
    inline_payload_limit_mb: int = 25,
) -> Dict[str, Any]:
    """Export the active design, hash it, POST to /api/runs, return witness response.

    Steps:
      1. Generate temp path.
      2. design.exportManager.execute(createFusionArchiveExportOptions(...))
      3. SHA-256 the bytes (streamed).
      4. POST to /api/runs with inputs[0] = inline base64 of the F3D bytes
         (for archives ≤ inline_payload_limit_mb) so scruple-web can store
         them in its standard input-artifact path.
      5. Cleanup the temp file.
    """
    tmp_dir = tempfile.gettempdir()
    filename = os.path.join(tmp_dir, f"scruple_fusion_{uuid.uuid4().hex}.f3d")
    try:
        opts = design.exportManager.createFusionArchiveExportOptions(filename, design.rootComponent)
        ok = design.exportManager.execute(opts)
        if not ok:
            raise RuntimeError("Fusion ExportManager.execute() returned False")

        if not os.path.exists(filename):
            raise RuntimeError(f"ExportManager said ok but no file at {filename}")

        size = os.path.getsize(filename)
        digest = _sha256_file(filename)

        # Decide inline vs no-inline. Fusion archives can be large (linked
        # subassemblies, simulation data); over the limit we send hash-only
        # and rely on the user retaining the file out-of-band. The leaf still
        # binds the hash; loss of inline does not break provenance.
        inputs = []
        if size <= inline_payload_limit_mb * 1024 * 1024:
            with open(filename, "rb") as f:
                inline_b64 = base64.b64encode(f.read()).decode("ascii")
            inputs.append({
                "kind": "other",
                "filename": os.path.basename(filename),
                "contentType": "application/octet-stream",
                "inlineBase64": inline_b64,
            })

        machine_manifest = build_machine_manifest(fusion_version)
        prompt = f"fusion-export ({trigger}) — {design.name} @ {int(time.time())}"

        # We don't go through /api/runs (that path is for Modal-executed
        # workflows). Fusion's output IS the .f3d bytes themselves — there's
        # no Modal-side execution to attest. /api/witness/cad ingests the
        # bytes directly and binds them into a v2.2 leaf with our
        # machine_manifest.
        if not inputs:
            # File too large for inline — surface a clear error.
            raise RuntimeError(
                f"Fusion archive {size} bytes exceeds the inline payload limit; "
                f"large-file support lands in a later phase."
            )
        inline_b64 = inputs[0]["inlineBase64"]
        resp = client.witness_cad(
            project_id=project_id,
            filename=os.path.basename(filename),
            inline_base64=inline_b64,
            machine_manifest=machine_manifest,
            content_type="application/octet-stream",
            prompt=prompt,
        )
        # Decorate response with the local view for logging / palette display.
        resp = dict(resp) if isinstance(resp, dict) else {}
        resp.setdefault("local", {})
        resp["local"]["filename"] = filename
        resp["local"]["size_bytes"] = size
        resp["local"]["sha256"] = digest
        resp["local"]["trigger"] = trigger
        return resp
    finally:
        try:
            os.unlink(filename)
        except FileNotFoundError:
            pass
        except Exception:
            # Don't let cleanup failure mask the witness result.
            pass


def ensure_project_bound(
    design: Any,
    client: ScrupleClient,
    *,
    group: str = "Scruple",
    project_name_fallback: str = "Untitled Fusion Design",
) -> int:
    """Read project_id from design.attributes; create + bind on first witness."""
    attrs = design.attributes
    existing = attrs.itemByName(group, "project_id")
    if existing is not None and existing.value:
        try:
            return int(existing.value)
        except ValueError:
            pass  # corrupted — recreate
    name = getattr(design, "name", None) or project_name_fallback
    proj = client.create_project(name=name, kind="cad")
    pid = int(proj.get("id"))
    attrs.add(group, "project_id", str(pid))
    return pid


def write_lock_attributes(design: Any, lock_response: Dict[str, Any], *, group: str = "Scruple") -> None:
    """Embed lock result back into the Fusion document so the chain survives reopen."""
    attrs = design.attributes
    scr_id = lock_response.get("scrId") or lock_response.get("scr_id")
    merkle_root = lock_response.get("merkleRoot") or lock_response.get("merkle_root")
    locked_at = lock_response.get("lockedAt") or lock_response.get("locked_at")
    if scr_id:
        attrs.add(group, "scr_id", str(scr_id))
    if merkle_root:
        attrs.add(group, "merkle_root", str(merkle_root))
    if locked_at is not None:
        attrs.add(group, "locked_at", str(locked_at))
    # Full record JSON-encoded for archival; values must be strings.
    attrs.add(group, "lock_record_json", json.dumps(lock_response))
