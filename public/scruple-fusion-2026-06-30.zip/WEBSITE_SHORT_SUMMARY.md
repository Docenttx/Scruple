# Scruple for Fusion 360 — short summary (for website use)

A tight, drop-in-anywhere description. ~200 words. Tone matches the existing
Scruple Studio and SCRUPLE Standard pages: institutional, technical, no
exclamation points, no AI-marketing language, no claims past the boundary.

---

## One-line

Cryptographic provenance for Fusion 360, running quietly as you work and
locked to a public ledger when you're ready.

---

## Short summary (paste-ready)

**Scruple for Fusion 360** captures every save and every working interval
as a cryptographic record, then commits the entire session to a public
ledger as a single court-ready receipt. It runs as a small Scruple panel
inside Fusion. You model normally — Scruple watches in the background.

**How a session works.** You install Scruple from the Fusion add-in store.
A panel docks to the right of your modeling view. Every save is silently
captured. Every five minutes — if you've changed anything — a fresh
snapshot enters the chain. When you click **Lock & Anchor**, the entire
chain is committed to three independent public ledgers (Ravencoin testnet,
IPFS, Arweave) as a single tamper-evident receipt. You get an SCR-ID and
a verification URL anyone can check.

**What it proves.** That this exact design file existed in this state at
the witnessed time, signed, and is unaltered since. The receipt is
self-authenticating under Federal Rule of Evidence 902 — admissible in
court without you or Autodesk or Scruple appearing to testify. The public
ledger is the witness.

**What we never hold.** Your design stays in Fusion and Fusion Team.
Scruple holds only the cryptographic commitments — hashes and signatures,
never your geometry.

---

## Even shorter (50 words, for nav blurbs / cards)

Scruple for Fusion 360 silently witnesses every save and working interval
as you model, then locks the whole chain to three public ledgers as a
single court-admissible receipt. Your design stays in Fusion. We hold
only the hashes.

---

## One-sentence (for footer/meta)

Cryptographic, court-admissible provenance for Fusion 360 — runs in the
background, locks to a public ledger in one click.

---

## Designer notes

- "Court-ready" / "court-admissible" / FRE 902 — these are the headline
  differentiators vs. C2PA. Keep them prominent.
- The "you model normally" framing is load-bearing. Don't surface manual
  export workflows — autonomous capture is the product story.
- Do not surface Hard Scruple, FPGA, hardware-witnessing, or memory
  isolation. The public-facing copy is Soft Scruple only.
- Pricing TBD; current language is "pilot access available" same as the
  Studio page.
- Once the add-in MVP is rendering, replace placeholder copy with a
  screenshot of the palette docked + the receipt page.
