# Autodesk SSO setup — APS app registration

The Scruple Fusion add-in supports signing in with Autodesk SSO so that
the user's existing Fusion / Autodesk identity flows directly into Scruple
without a separate account. This document explains how to register Scruple
as an APS (Autodesk Platform Services) app so the "Sign in with Autodesk"
button on `/login` becomes live.

## Why Autodesk SSO matters for the Fusion add-in

- **Zero friction.** Every Fusion user is already signed in to Autodesk. A
  Fusion add-in that asks them to create a separate Scruple account feels
  foreign. Autodesk SSO inherits the identity they already have.
- **ID alignment.** The same Autodesk ID owns the user's Fusion Team
  designs. Provenance receipts tied to that ID can be audited end-to-end
  against Autodesk's records.
- **Brand fit.** A Fusion add-in is an Autodesk-ecosystem product. Native
  signin matches the platform.

## What you need to do (one-time, ~15 minutes)

### 1. Sign in to APS

Go to https://aps.autodesk.com and click **Sign In** (top-right). Use the
Autodesk account you want to OWN this APS app — typically the founder's
account or a dedicated dev account. This account will be the admin for
the registration.

### 2. Create a new APS app

- Navigate to **My Apps** (top menu).
- Click **Create App**.
- Pick **Traditional Web App** as the application type.
- App name: **Scruple for Fusion 360**
- Description: *Cryptographic provenance for Autodesk Fusion 360 designs.*
- App icon: optional — upload the Scruple logo if you have a 256×256 PNG.

### 3. Configure the callback URL

The callback URL is what Autodesk redirects to after the user
authenticates. It must match exactly:

```
https://scruple.stooges.ai/api/auth/callback/autodesk
```

(For local dev: `http://localhost:3001/api/auth/callback/autodesk`)

If you want both, list them both — APS allows multiple callbacks per app.

### 4. Enable the APIs

In the **APIs you want to use** section, enable at minimum:

- **OAuth 2.0 / Identity Service** — required for signin
- *(optional later)* **Data Management API** — needed if we ever want to
  read the user's Fusion Team designs server-side for the Phase 6 cloud
  verifier path

### 5. Set the scopes

The Scruple add-in requests these scopes:

- `user-profile:read` — read the user's name, email, profile picture
- `openid` — OpenID Connect signin (standard)

Add both in the **Scopes** section.

### 6. Get your credentials

After saving, APS shows your **Client ID** and **Client Secret**. Copy
them. The Secret is shown ONCE — if you lose it you have to regenerate.

### 7. Wire into scruple-web

On the Oracle host, edit `/data/scruple-web/.env.local` and add:

```bash
AUTODESK_CLIENT_ID=<your client id>
AUTODESK_CLIENT_SECRET=<your client secret>
```

Then restart the dev server:

```bash
pkill -f "next dev"
cd /data/scruple-web && PORT=3001 nohup npm run dev > /tmp/scruple-web-dev.log 2>&1 &
```

The `/login` page will now show **"Sign in with Autodesk"** as the
primary button (above Google).

### 8. Test

In the Fusion add-in palette, click "Sign in" → opens `/login` → you
should see both Autodesk and Google buttons. Click Autodesk → APS
consent screen → after consent you land back in the palette with a
freshly minted API key in the URL, signed in.

## Pricing notes

APS has a free dev tier sufficient for the Fusion add-in's signin needs.
Production at scale incurs charges based on API call volume — for
authentication-only usage the costs are negligible (well under $1/month
for moderate user volumes).

If we ever want to read the user's Fusion Team designs server-side
(Phase 6 cloud verifier), Data Management API calls would incur cost
per API call. That's a future decision.

## Falling back when Autodesk is down

NextAuth handles per-provider failures gracefully — if Autodesk's OAuth
endpoint is down, the user can fall back to Google signin (Google button
still shows). No code change needed.

## Revoking

To revoke Autodesk OAuth access for a specific user, they go to
https://accounts.autodesk.com → Apps → Scruple → Revoke. Their existing
NextAuth session in our DB remains until they `/api/auth/signout`.

To take the whole integration offline, comment out the AUTODESK_CLIENT_ID
in `.env.local` and restart — the provider drops from the config.

## What's wired in code

- `/data/scruple-web/lib/auth/auth.ts` — `Autodesk` provider config + conditional
  inclusion based on env vars
- `/data/scruple-web/app/login/page.tsx` — "Sign in with Autodesk" button,
  conditional on `AUTODESK_CLIENT_ID` being set

Both already shipped. APS registration is the only step left.
