# Probe 5.3 — Background thread + Fusion API access
#
# Spawns a Python daemon thread. From the thread, attempts to read
# adsk.core.Application.get() and to update ui.progressBar.message.
#
# If it works: we can call Fusion APIs from threads directly (simpler).
# If it crashes / blocks / segfaults: we must marshal via app.fireCustomEvent
# from the thread, with the handler running on the Fusion API thread.
#
# Watch TEXT COMMANDS for output. If Fusion locks up or crashes, that IS
# the answer — note which line was running last.

import adsk.core
import threading
import time
import traceback

_thread_ref = None
_stop_event = threading.Event()


def _worker():
    try:
        for i in range(15):
            if _stop_event.is_set():
                return
            try:
                app = adsk.core.Application.get()
                ui = app.userInterface
                # Try a UI update from the bg thread.
                ui.progressBar.message = f"probe 5.3 tick #{i + 1}"
                print(f"[probe 5.3] bg thread tick #{i + 1}: ui.progressBar.message updated")
            except Exception:
                print(f"[probe 5.3] bg thread tick #{i + 1} EXCEPTION:\n{traceback.format_exc()}")
            time.sleep(2)
    except Exception:
        print(f"[probe 5.3] worker died:\n{traceback.format_exc()}")


def run(context):
    global _thread_ref
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        ui.messageBox(
            "Probe 5.3: starting background thread for 30 seconds.\n"
            "Watch TEXT COMMANDS for tick lines.\n"
            "If Fusion freezes/crashes, write down the LAST tick number."
        )
        _stop_event.clear()
        _thread_ref = threading.Thread(target=_worker, daemon=True, name="probe53")
        _thread_ref.start()
    except Exception:
        print(f"PROBE 5.3 RUN EXCEPTION:\n{traceback.format_exc()}")


def stop(context):
    global _thread_ref
    try:
        _stop_event.set()
        if _thread_ref is not None:
            _thread_ref.join(timeout=3.0)
            print(f"PROBE 5.3 SUMMARY: thread alive after stop? {_thread_ref.is_alive()}")
        _thread_ref = None
    except Exception:
        print(f"PROBE 5.3 STOP EXCEPTION:\n{traceback.format_exc()}")
