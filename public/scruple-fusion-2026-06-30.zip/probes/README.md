# Desktop probes (Phase 5)

Six standalone Python snippets. Each is meant to be pasted into Fusion 360's
**Utilities → Scripts and Add-Ins → Scripts → Create New Script** dialog,
run, and the TEXT COMMANDS console output sent back.

These confirm Fusion API assumptions the build plan rests on. They take
~10-15 minutes each and require a Mac or Windows workstation with Fusion
360 installed (Oracle host can't run desktop Fusion).

| # | File | What it confirms |
|---|------|------------------|
| 5.1 | `probe_5_1_export_manager.py`     | `.f3d` export works headless on parametric / imported STEP / linked-subassembly |
| 5.2 | `probe_5_2_document_saved.py`     | `documentSaved` fires on save, does NOT fire on recovery autosave |
| 5.3 | `probe_5_3_background_thread.py`  | Whether Python threads can call Fusion API directly or must marshal via `fireCustomEvent` |
| 5.4 | `probe_5_4_palette_react_ui.py`   | ⚠ load-bearing — palette renders scruple-web's React UI via Qt WebEngine |
| 5.5 | `probe_5_5_browser_handoff.py`    | `webbrowser.open()` + `scruple-fusion://` custom URL scheme round-trip |
| 5.6 | `probe_5_6_ui_button_registration.py` | Scruple panel + 3 buttons appear in FusionSolidEnvironment |

Run them in order. Each prints to the TEXT COMMANDS console. Copy that
output verbatim and send back.

## Output format I'm expecting

For each probe, send:

```
=== PROBE 5.X ===
Fusion version:     <e.g., 2.0.21127>
OS:                 <macOS / Windows>
Result:             pass | fail
Console output:
<full text>
Notes:              <anything surprising>
```
