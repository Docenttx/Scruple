# Probe 5.6 — UI button registration
#
# Confirms a Scruple toolbar panel + 3 buttons appear inside
# the FusionSolidEnvironment workspace.

import adsk.core
import traceback

PANEL_ID = "scruple_probe_panel"
WORKSPACE_ID = "FusionSolidEnvironment"
TARGET_TOOLBAR = "SolidScriptsAddinsPanel"

CMD_DEFS = [
    ("scruple_probe_witness", "Witness now", "Witness the current design"),
    ("scruple_probe_lock", "Lock & Anchor", "Lock the project to RVN+IPFS+Arweave"),
    ("scruple_probe_dashboard", "Open dashboard", "Open scruple.ai dashboard"),
]

_handlers = []


def run(context):
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        ws = ui.workspaces.itemById(WORKSPACE_ID)
        if not ws:
            ui.messageBox(f"Workspace {WORKSPACE_ID} not found. Are you in the Design workspace?")
            return

        panels = ws.toolbarPanels
        existing = panels.itemById(PANEL_ID)
        if existing:
            existing.deleteMe()
        panel = panels.add(PANEL_ID, "Scruple Probe")

        for cid, title, tip in CMD_DEFS:
            existing_def = ui.commandDefinitions.itemById(cid)
            if existing_def:
                existing_def.deleteMe()
            cd = ui.commandDefinitions.addButtonDefinition(cid, title, tip)
            panel.controls.addCommand(cd)
            print(f"[probe 5.6] registered '{title}' ({cid})")

        ui.messageBox(
            "Probe 5.6: a 'Scruple Probe' panel should now be in your Design workspace.\n"
            "Verify the three buttons (Witness now / Lock & Anchor / Open dashboard) appear.\n"
            "Report whether they all render and whether clicking them shows a 'no command handler' error."
        )
    except Exception:
        print(f"PROBE 5.6 EXCEPTION:\n{traceback.format_exc()}")


def stop(context):
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        ws = ui.workspaces.itemById(WORKSPACE_ID)
        if ws:
            panel = ws.toolbarPanels.itemById(PANEL_ID)
            if panel:
                panel.deleteMe()
        for cid, _, _ in CMD_DEFS:
            cd = ui.commandDefinitions.itemById(cid)
            if cd:
                cd.deleteMe()
        print(f"PROBE 5.6 cleanup done")
    except Exception:
        print(f"PROBE 5.6 STOP EXCEPTION:\n{traceback.format_exc()}")
