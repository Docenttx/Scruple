# Probe 5.4 — Palette renders scruple-web React UI  ⚠ LOAD-BEARING
#
# This validates the Option 2 architecture. If it works, the entire build
# plan is green. If it fails, we fall back to Option 3 (native HTML
# palette) which is a +1 week task.
#
# Steps:
#   1. Use the API key from DESKTOP_READY.md (or mint a fresh one — see
#      that doc for the curl recipe). The default URL below points at
#      scruple.stooges.ai over real HTTPS, so no SSH tunnel needed.
#   2. Replace REPLACE_WITH_YOUR_KEY in EMBED_URL below.
#   3. Paste this into Scripts and Add-Ins → Scripts → Create New Script → Run.
#
# WHAT TO WATCH:
#   - Does the palette open?
#   - Does the React app shell load (dark background, "Scruple for Fusion" header)?
#   - Does the project picker dropdown populate from the API?
#   - Click "Witness now" — what happens?
#   - Click "Open dashboard" — does it open the system browser?
#   - Open the embedded Chromium devtools if possible (varies by Fusion version)

import adsk.core
import traceback

# Edit this to include your API key in the URL.
# Default target is the public Cloudflare tunnel — no SSH tunnel needed.
EMBED_URL = "https://scruple.stooges.ai/embed/fusion?token=REPLACE_WITH_YOUR_KEY"

PALETTE_ID = "scruple_probe_palette"

_palette_ref = None


def run(context):
    global _palette_ref
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        if "REPLACE_WITH_YOUR_KEY" in EMBED_URL:
            ui.messageBox(
                "EDIT THE SCRIPT FIRST.\n"
                "Set EMBED_URL at the top to include your API key.\n"
                "Open: Utilities → Scripts and Add-Ins → Edit on this script."
            )
            return

        existing = ui.palettes.itemById(PALETTE_ID)
        if existing:
            existing.deleteMe()

        pal = ui.palettes.add(
            id=PALETTE_ID,
            name="Scruple Probe",
            htmlFileURL=EMBED_URL,
            isVisible=True,
            showCloseButton=True,
            isResizable=True,
            width=420,
            height=820,
            useNewWebBrowser=True,  # critical — modern Chromium
        )
        _palette_ref = pal
        ui.messageBox(
            "Palette mounted with EMBED_URL.\n"
            "Verify:\n"
            "  ✓ Dark background renders\n"
            "  ✓ 'Scruple for Fusion' header visible\n"
            "  ✓ Project picker dropdown populates\n"
            "  ✓ 'Witness now' + 'Lock & Anchor' buttons appear\n"
            "Send back observed behavior."
        )
    except Exception:
        if 'ui' in dir():
            ui.messageBox(f"PROBE 5.4 EXCEPTION:\n{traceback.format_exc()}")
        print(f"PROBE 5.4 EXCEPTION:\n{traceback.format_exc()}")


def stop(context):
    global _palette_ref
    try:
        if _palette_ref is not None:
            _palette_ref.deleteMe()
            _palette_ref = None
    except Exception:
        pass
