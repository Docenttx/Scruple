# Probe 5.5 — Browser handoff for payment + custom URL scheme callback
#
# Two halves:
#   A) webbrowser.open() opens a URL in the system browser
#   B) scruple-fusion:// custom URL scheme round-trips back to the add-in
#
# Half B requires the install.sh / install.bat to have already registered
# the scheme. If not, this probe will fall through to the local-HTTP listener.
#
# Test on BOTH Mac AND Windows.

import adsk.core
import platform
import socket
import time
import threading
import traceback
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

_server_ref = None


class _CB(BaseHTTPRequestHandler):
    received = []

    def log_message(self, *args, **kwargs):
        pass

    def do_GET(self):
        u = urlparse(self.path)
        params = {k: v[0] for k, v in parse_qs(u.query).items()}
        _CB.received.append({"path": u.path, "params": params, "at": time.time()})
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"<html><body>Callback received. Close this window.</body></html>")


def _free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close()
    return p


def run(context):
    global _server_ref
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        # Half A — open a known URL in the system browser
        url = "https://scruple.ai"
        ok = webbrowser.open(url)
        print(f"[probe 5.5] webbrowser.open('{url}') returned {ok}")

        # Half B — start a local HTTP listener + open scruple-fusion:// to test
        # the scheme handler chain
        port = _free_port()
        httpd = HTTPServer(("127.0.0.1", port), _CB)
        _server_ref = httpd
        threading.Thread(target=httpd.serve_forever, daemon=True, name="probe55").start()

        scheme_url = f"scruple-fusion://test?probe=5_5&port={port}&t={int(time.time())}"
        fallback_url = f"http://127.0.0.1:{port}/callback?probe=5_5&fallback=1"

        opened = webbrowser.open(scheme_url)
        print(f"[probe 5.5] webbrowser.open(scheme '{scheme_url}') returned {opened}")
        print(f"[probe 5.5] also try: open '{fallback_url}' manually if scheme handler isn't installed")

        ui.messageBox(
            "Probe 5.5 running.\n"
            "1. Did scruple.ai open in your browser?\n"
            f"2. Did clicking '{scheme_url}' prompt to open ScrupleFusion?\n"
            f"3. As a fallback, paste {fallback_url} into a browser.\n"
            "Watch TEXT COMMANDS for received callbacks. Stop the script when done."
        )

        # Wait up to 60s for callbacks
        deadline = time.time() + 60
        while time.time() < deadline:
            if _CB.received:
                for r in _CB.received[-3:]:
                    print(f"[probe 5.5] callback: {r}")
                break
            time.sleep(1)

        if not _CB.received:
            print(f"[probe 5.5] no callbacks received in 60s")
        else:
            print(f"PROBE 5.5 PASS: {len(_CB.received)} callbacks received via local listener")
    except Exception:
        print(f"PROBE 5.5 EXCEPTION:\n{traceback.format_exc()}")


def stop(context):
    global _server_ref
    try:
        if _server_ref:
            _server_ref.shutdown()
            _server_ref = None
        print(f"PROBE 5.5 SUMMARY: platform={platform.system()} callbacks={len(_CB.received)}")
    except Exception:
        pass
