# Probe 5.1 — ExportManager headless
#
# Confirms: design.exportManager.createFusionArchiveExportOptions(...) +
# .execute() writes an .f3d file without showing any dialog.
#
# Paste this into:  Utilities → Scripts and Add-Ins → Scripts → Create New Script
# Run it with: a hand-built parametric model open, then an imported STEP open,
# then a linked-subassembly open. Send the output for all three.

import adsk.core
import adsk.fusion
import os
import tempfile
import time
import traceback


def run(context):
    ui = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = adsk.fusion.Design.cast(app.activeProduct)
        if not design:
            ui.messageBox("No active Fusion design. Open one and re-run.")
            return

        root = design.rootComponent
        em = design.exportManager

        tmp_dir = tempfile.gettempdir()
        out_path = os.path.join(tmp_dir, f"scruple_probe_5_1_{int(time.time())}.f3d")

        # ── Build options + execute. Should be silent (no dialog).
        opts = em.createFusionArchiveExportOptions(out_path, root)
        t0 = time.time()
        ok = em.execute(opts)
        dt_ms = int((time.time() - t0) * 1000)

        if not ok:
            print(f"PROBE 5.1 FAIL: execute() returned False")
            return

        if not os.path.exists(out_path):
            print(f"PROBE 5.1 FAIL: execute() ok=True but no file at {out_path}")
            return

        size = os.path.getsize(out_path)
        print(f"PROBE 5.1 PASS")
        print(f"  filename:  {out_path}")
        print(f"  size:      {size} bytes")
        print(f"  duration:  {dt_ms} ms")
        print(f"  design:    {design.parentDocument.name}")
        print(f"  components in root: {root.allOccurrences.count}")

        try:
            os.unlink(out_path)
        except Exception:
            pass

    except Exception:
        if ui:
            ui.messageBox(f"PROBE 5.1 EXCEPTION:\n{traceback.format_exc()}")
        print(f"PROBE 5.1 EXCEPTION:\n{traceback.format_exc()}")
