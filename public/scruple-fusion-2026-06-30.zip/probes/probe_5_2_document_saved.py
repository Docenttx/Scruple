# Probe 5.2 — documentSaved event
#
# Hook the event. Save the active document. Confirm the event fires.
# Save again immediately. Confirm fires again.
# Modify file, wait 5+ minutes for recovery autosave, confirm the event
# does NOT fire (validates our hypothesis that recovery autosave is internal
# Autodesk plumbing, not user-facing save).

import adsk.core
import adsk.fusion
import time
import traceback

_handler_ref = None


class _SavedHandler(adsk.core.DocumentEventHandler):
    def __init__(self):
        super().__init__()
        self.fired_at = []

    def notify(self, args):
        try:
            doc_name = args.document.name if args.document else "?"
            t = time.time()
            self.fired_at.append((t, doc_name))
            print(f"[probe 5.2] documentSaved fired at t={t:.1f} doc={doc_name}")
        except Exception:
            print(f"[probe 5.2] handler exception:\n{traceback.format_exc()}")


def run(context):
    global _handler_ref
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        h = _SavedHandler()
        app.documentEvents.documentSaved.add(h)
        _handler_ref = h  # retain or Fusion GCs it

        ui.messageBox(
            "Probe 5.2 armed. Now:\n"
            "  1. Cmd+S (or File → Save) — should fire.\n"
            "  2. Cmd+S again immediately — should fire.\n"
            "  3. Make a small edit, then WAIT 6 minutes.\n"
            "     Recovery autosave should NOT fire this event.\n"
            "Watch TEXT COMMANDS for [probe 5.2] lines. Report counts."
        )
    except Exception:
        print(f"PROBE 5.2 EXCEPTION:\n{traceback.format_exc()}")


def stop(context):
    global _handler_ref
    try:
        if _handler_ref is not None and len(_handler_ref.fired_at) > 0:
            print(f"PROBE 5.2 SUMMARY: fired {len(_handler_ref.fired_at)} times")
            for t, n in _handler_ref.fired_at:
                print(f"  - t={t:.1f} doc={n}")
        _handler_ref = None
    except Exception:
        print(f"PROBE 5.2 stop exception:\n{traceback.format_exc()}")
