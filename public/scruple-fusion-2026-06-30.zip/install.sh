#!/usr/bin/env bash
# install.sh — copy ScrupleFusion into Fusion 360's AddIns directory (macOS).
#
# Usage:
#   ./install.sh [--link]
#
# Default: copies the add-in into the user's Fusion AddIns directory.
# With --link: symlinks instead (useful during development).

set -euo pipefail

SRC_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
ADDIN_DIR="${HOME}/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/ScrupleFusion"

if [[ "${1:-}" == "--link" ]]; then
  echo "Symlinking $SRC_DIR → $ADDIN_DIR"
  mkdir -p "$(dirname "$ADDIN_DIR")"
  rm -rf "$ADDIN_DIR"
  ln -s "$SRC_DIR" "$ADDIN_DIR"
else
  echo "Copying $SRC_DIR → $ADDIN_DIR"
  mkdir -p "$ADDIN_DIR"
  rsync -av --delete \
    --exclude='__pycache__' --exclude='.pytest_cache' \
    --exclude='.venv' --exclude='tests' --exclude='palette_dev' \
    --exclude='.git' --exclude='node_modules' \
    "$SRC_DIR/" "$ADDIN_DIR/"
fi

cat <<'EOF'

Installed. To complete setup:

  1. Open Fusion 360
  2. Utilities → Scripts and Add-Ins (or Shift+S)
  3. Add-Ins tab → ScrupleFusion → Run
  4. The Scruple palette should dock on the right
  5. Paste your API key from scruple.ai → Account → API Keys

To enable Run on Startup, tick that box in the Scripts and Add-Ins dialog.
EOF
