"""ScrupleFusion add-in entry point.

Fusion loads this module at startup (runOnStartup: true in the manifest).
Two top-level functions are required: run(context) and stop(context).

Architecture: Option 2 — the palette loads scruple-web's React UI directly
via Fusion's embedded Qt WebEngine. This file is the host shell: it sets up
the palette, the auto-witness background loop, the documentSaved hook, and
the bridge between Fusion's Python API and the React UI inside the palette.

The real work happens in the lib/ modules. Keep this file as thin as
possible — every line here costs blast radius if it crashes inside Fusion.
"""

import os
import sys
import traceback

# Make lib/ importable without polluting sys.path globally.
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
if _THIS_DIR not in sys.path:
    sys.path.insert(0, _THIS_DIR)

# Fusion modules are only available when running inside Fusion. Tests
# import via lib.fusion_mocks. The add-in's lifecycle code below is gated
# behind an `if _IN_FUSION` so test imports never blow up on a desktop
# without Fusion installed.
try:
    import adsk.core  # noqa: F401
    import adsk.fusion  # noqa: F401
    _IN_FUSION = True
except ImportError:
    _IN_FUSION = False

from lib import scruple_client, witness, auto_witness, palette_host  # noqa: E402

_handlers = []  # Fusion needs to retain event-handler refs or they GC.
_auto_witness_thread = None
_palette = None


def run(context):
    """Add-in startup hook called by Fusion."""
    if not _IN_FUSION:
        return
    try:
        global _palette, _auto_witness_thread
        app = adsk.core.Application.get()
        ui = app.userInterface

        # 1. Mount the palette pointing at scruple-web's /embed/fusion route.
        _palette = palette_host.create_palette(app, ui)

        # 2. Hook documentSaved → immediate witness.
        on_saved = palette_host.make_document_saved_handler(app, ui, _palette)
        app.documentEvents.documentSaved.add(on_saved)
        _handlers.append(on_saved)

        # 3. Register the Scruple toolbar panel + buttons.
        palette_host.install_ui_commands(app, ui, _handlers)

        # 4. Start the ambient auto-witness loop.
        _auto_witness_thread = auto_witness.start(app, ui, _palette)

        # 5. Register custom URL scheme handler (for OAuth + payment callbacks).
        palette_host.register_url_scheme_handler(app, ui, _palette)

    except Exception:
        if _IN_FUSION:
            try:
                ui.messageBox(
                    'Scruple add-in failed to start:\n\n' + traceback.format_exc()
                )
            except Exception:
                pass


def stop(context):
    """Add-in shutdown hook called by Fusion."""
    if not _IN_FUSION:
        return
    try:
        global _palette, _auto_witness_thread
        if _auto_witness_thread is not None:
            auto_witness.stop(_auto_witness_thread)
            _auto_witness_thread = None
        if _palette is not None:
            try:
                _palette.deleteMe()
            except Exception:
                pass
            _palette = None
        _handlers.clear()
        palette_host.uninstall_ui_commands()
    except Exception:
        pass
