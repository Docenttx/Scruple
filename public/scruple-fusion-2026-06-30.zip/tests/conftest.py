"""pytest configuration: make lib/ importable + provide common fixtures."""

from __future__ import annotations

import os
import sys

import pytest

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from lib import fusion_mocks  # noqa: E402


@pytest.fixture
def mock_app():
    """Fresh MockApp with synthesized export bytes (unique per call)."""
    return fusion_mocks.MockApp()


@pytest.fixture
def mock_app_with_fixture():
    """Factory: MockApp whose ExportManager writes the given bytes."""
    def _make(payload: bytes):
        return fusion_mocks.make_app_with_fixture(payload)
    return _make


def _scruple_base() -> str:
    return os.environ.get("SCRUPLE_BASE", "http://127.0.0.1:3001")


def _scruple_api_key() -> str | None:
    return os.environ.get("SCRUPLE_API_KEY")


@pytest.fixture
def live_client():
    """A ScrupleClient pointed at a live scruple-web; skip if not configured.

    Requires both SCRUPLE_BASE (defaults to localhost:3001) AND a usable
    auth credential (SCRUPLE_API_KEY or SCRUPLE_SESSION_COOKIE).
    """
    from lib.scruple_client import ScrupleClient
    api_key = _scruple_api_key()
    session_cookie = os.environ.get("SCRUPLE_SESSION_COOKIE")
    if not api_key and not session_cookie:
        pytest.skip("SCRUPLE_API_KEY or SCRUPLE_SESSION_COOKIE not set; live test skipped")
    return ScrupleClient(
        base_url=_scruple_base(),
        api_key=api_key,
        session_cookie=session_cookie,
    )
