"""Tests for the background auto-witness loop.

We test the timer behavior using a short interval and an external 'dirty'
gate. The actual witness call is fed via fireCustomEvent — we capture
those events instead of doing a real witness.
"""

from __future__ import annotations

import time

import pytest

from lib import auto_witness, fusion_mocks


def test_loop_fires_when_dirty():
    app = fusion_mocks.MockApp()
    captured = []
    app.registerCustomEvent(auto_witness.CUSTOM_EVENT_TICK).add(lambda _: captured.append(time.time()))

    # design.isDirty is True by default in the mock
    t = auto_witness.start(app, ui=None, palette=None, interval_seconds=0.2)
    try:
        time.sleep(0.7)
    finally:
        auto_witness.stop(t)

    # Should have fired at least twice in 0.7s at 0.2s interval (0.2, 0.4, 0.6)
    assert len(captured) >= 2, f"expected ≥2 ticks, got {len(captured)}"


def test_loop_skips_when_clean():
    app = fusion_mocks.MockApp()
    app.activeDocument.design.isDirty = False
    captured = []
    app.registerCustomEvent(auto_witness.CUSTOM_EVENT_TICK).add(lambda _: captured.append(time.time()))

    t = auto_witness.start(app, ui=None, palette=None, interval_seconds=0.2)
    try:
        time.sleep(0.5)
    finally:
        auto_witness.stop(t)

    assert len(captured) == 0


def test_stop_terminates_thread():
    app = fusion_mocks.MockApp()
    t = auto_witness.start(app, ui=None, palette=None, interval_seconds=0.2)
    assert t.is_alive()
    auto_witness.stop(t)
    assert not t.is_alive()
