"""Pure-mock tests — no live scruple-web required.

These verify the witness flow's structure: that a Fusion export gets hashed,
that ensure_project_bound writes the right attribute, etc. The actual HTTP
call is captured by a mock ScrupleClient.
"""

from __future__ import annotations

import hashlib
import os
from typing import Any, Dict, List

import pytest

from lib import fusion_mocks, witness


class CapturingClient:
    """ScrupleClient stand-in that records calls instead of making HTTP requests."""

    def __init__(self) -> None:
        self.created_projects: List[Dict[str, Any]] = []
        self.witnesses: List[Dict[str, Any]] = []
        self._next_project_id = 1000
        self._next_run_seq = 0
        self._prev_leaf = None

    def create_project(self, name: str, kind: str = "cad") -> Dict[str, Any]:
        pid = self._next_project_id
        self._next_project_id += 1
        proj = {"id": pid, "name": name, "kind": kind, "status": "unlocked"}
        self.created_projects.append(proj)
        return proj

    def witness_cad(self, project_id: int, *, filename: str, inline_base64: str,
                    machine_manifest: Dict[str, Any], content_type: str = "application/octet-stream",
                    prompt: str | None = None) -> Dict[str, Any]:
        self._next_run_seq += 1
        leaf = hashlib.sha256(
            (str(self._next_run_seq) + (self._prev_leaf or "")).encode()
        ).hexdigest()
        rec = {
            "ok": True,
            "iteration": {
                "id": self._next_run_seq,
                "project_id": project_id,
                "run_sequence": self._next_run_seq,
                "prev_record_hash": self._prev_leaf,
            },
            "leafHash": leaf,
            "runSequence": self._next_run_seq,
            "machineManifestHash": "deadbeef" * 8,
        }
        self._prev_leaf = leaf
        self.witnesses.append({
            "projectId": project_id,
            "filename": filename,
            "machineManifest": machine_manifest,
            "prompt": prompt,
            "inline_size_b64": len(inline_base64),
        })
        return rec


def test_ensure_project_bound_creates_and_persists(mock_app):
    design = mock_app.activeDocument.design
    client = CapturingClient()

    # First call → creates project + binds id into attributes
    pid = witness.ensure_project_bound(design, client)
    assert pid == 1000
    assert design.attributes.itemByName("Scruple", "project_id").value == "1000"
    assert len(client.created_projects) == 1

    # Second call → reuses, no new create
    pid2 = witness.ensure_project_bound(design, client)
    assert pid2 == 1000
    assert len(client.created_projects) == 1


def test_export_and_witness_hashes_bytes(mock_app):
    design = mock_app.activeDocument.design
    client = CapturingClient()
    pid = witness.ensure_project_bound(design, client)

    resp = witness.export_and_witness(design, client, pid)
    assert resp["ok"] is True
    assert resp["runSequence"] == 1
    assert "local" in resp
    assert resp["local"]["size_bytes"] > 0
    # SHA256 hex digests are 64 chars
    assert len(resp["local"]["sha256"]) == 64
    # filename should NOT exist anymore (cleaned up post-witness)
    assert not os.path.exists(resp["local"]["filename"])


def test_chain_advances_across_witnesses(mock_app):
    design = mock_app.activeDocument.design
    client = CapturingClient()
    pid = witness.ensure_project_bound(design, client)

    leaves = []
    for i in range(5):
        resp = witness.export_and_witness(design, client, pid, trigger=f"test-{i}")
        leaves.append(resp["leafHash"])
        # And the iteration's prev_record_hash should chain backwards
        if i > 0:
            assert resp["iteration"]["prev_record_hash"] == leaves[i - 1]

    assert len(set(leaves)) == 5  # all distinct
    assert client.witnesses[0]["projectId"] == pid


def test_machine_manifest_is_present():
    mm = witness.build_machine_manifest("2.0.20999")
    assert mm["host"] == "fusion360"
    assert mm["fusion_version"] == "2.0.20999"
    assert mm["addin"] == "scruple-fusion"
    assert mm["addin_version"] == witness.ADDIN_VERSION


def test_attributes_must_be_strings(mock_app):
    """design.attributes.add() enforces str — same as real Fusion."""
    design = mock_app.activeDocument.design
    with pytest.raises(TypeError):
        design.attributes.add("Scruple", "project_id", 1000)  # int rejected


def test_write_lock_attributes_serializes_full_record(mock_app):
    design = mock_app.activeDocument.design
    lock_resp = {
        "scrId": "SCR_DEADBEEF",
        "merkleRoot": "abcd1234" * 8,
        "lockedAt": 1700000000,
        "rvnTxid": "tx-abcd",
        "ipfsCid": "QmFoo",
        "arweaveUri": "ar://test",
    }
    witness.write_lock_attributes(design, lock_resp)
    assert design.attributes.itemByName("Scruple", "scr_id").value == "SCR_DEADBEEF"
    assert design.attributes.itemByName("Scruple", "merkle_root").value.startswith("abcd1234")
    full = design.attributes.itemByName("Scruple", "lock_record_json").value
    assert "SCR_DEADBEEF" in full
    assert "Qm" in full
