"""Live integration tests against a running scruple-web on :3001.

Requires:
  SCRUPLE_BASE              defaults to http://127.0.0.1:3001
  SCRUPLE_API_KEY           Bearer token (issued via /api/auth/keys)

If SCRUPLE_API_KEY is not set, all tests in this file are skipped.

What we cover:
  1. The API key validates and authorizes the same way a session cookie does.
  2. Project create + bind (via Fusion attributes) round-trips.
  3. The Fusion witness flow lands a leaf in scruple-web that's identical
     to what a canvas iteration would land (same fields, chained).
  4. Multiple witnesses chain correctly (prev_record_hash advances).
"""

from __future__ import annotations

import os
import time
import uuid

import pytest

from lib import fusion_mocks, witness


# ---- fixtures specific to this file ----

@pytest.fixture
def doc_with_unique_name(request):
    """Mock app whose document name is unique per test invocation
    so the (user_id, name) UNIQUE constraint on projects doesn't collide.
    """
    app = fusion_mocks.MockApp()
    app.activeDocument.design.name = f"pytest-fusion-{int(time.time())}-{uuid.uuid4().hex[:6]}"
    return app


# ---- tests ----

def test_bearer_auth_lists_projects(live_client):
    """The Bearer header validates and returns the user's project list."""
    projects = live_client.list_projects()
    assert isinstance(projects, list)


def test_create_project_and_bind(live_client, doc_with_unique_name):
    """ensure_project_bound creates a project the FIRST time + reuses thereafter."""
    design = doc_with_unique_name.activeDocument.design
    pid = witness.ensure_project_bound(design, live_client)
    assert isinstance(pid, int) and pid > 0
    # Sanity: project shows up in list
    listed = live_client.list_projects()
    assert any(p["id"] == pid for p in listed), "newly created project not in list"

    # Second call → reuses
    pid2 = witness.ensure_project_bound(design, live_client)
    assert pid == pid2


def test_single_witness_lands_iteration(live_client, doc_with_unique_name):
    """One witness POST → one iteration row with a real leaf hash."""
    design = doc_with_unique_name.activeDocument.design
    pid = witness.ensure_project_bound(design, live_client)

    resp = witness.export_and_witness(design, live_client, pid, trigger="pytest-single")
    assert resp.get("ok") is True
    assert resp.get("runSequence") == 1
    assert resp.get("leafHash") and len(resp["leafHash"]) == 64

    # Fetch the project — iteration count = 1
    state = live_client.get_project(pid)
    iter_count = state.get("iterationCount") or len(state.get("iterations") or [])
    assert iter_count == 1


def test_five_witnesses_chain(live_client, doc_with_unique_name):
    """Five sequential witnesses → five chained leaves with advancing run_sequence."""
    design = doc_with_unique_name.activeDocument.design
    pid = witness.ensure_project_bound(design, live_client)

    leaves = []
    for i in range(5):
        resp = witness.export_and_witness(design, live_client, pid, trigger=f"pytest-chain-{i}")
        assert resp["ok"] is True
        assert resp["runSequence"] == i + 1
        leaves.append(resp["leafHash"])

    # All distinct (the mock varies bytes per execute call)
    assert len(set(leaves)) == 5

    # Fetch iterations — should be 5, ordered
    state = live_client.get_project(pid)
    iters = state.get("iterations") or []
    assert len(iters) == 5
    seqs = sorted([row["run_sequence"] for row in iters])
    assert seqs == [1, 2, 3, 4, 5]


def test_invalid_bearer_returns_401(live_client):
    """A bogus Bearer token results in 401, never silent fallback."""
    from lib.scruple_client import ScrupleClient, ScrupleClientError
    bad = ScrupleClient(base_url=live_client.base_url, api_key="sk_test_INVALID_GARBAGE")
    with pytest.raises(ScrupleClientError) as ei:
        bad.list_projects()
    assert ei.value.status == 401


def test_machine_manifest_hash_present_in_iteration(live_client, doc_with_unique_name):
    """The witness response surfaces machineManifestHash and it's stable per run."""
    design = doc_with_unique_name.activeDocument.design
    pid = witness.ensure_project_bound(design, live_client)
    resp = witness.export_and_witness(design, live_client, pid)
    mm_hash = resp.get("machineManifestHash")
    assert mm_hash is not None
    assert len(mm_hash) == 64
