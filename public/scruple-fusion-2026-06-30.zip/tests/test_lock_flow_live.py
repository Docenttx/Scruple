"""Live E2E test: create project → 3 witnesses → Stripe sandbox → chain-lock-pinned.

This is the full Phase 3 path. Skipped unless SCRUPLE_API_KEY is set AND
SCRUPLE_RUN_LIVE_LOCK_TEST=1 — chain locks hit real arlocal + IPFS + RVN
testnet, which we don't want firing on every CI run.

Side effects:
  - Creates a new scruple-web project with 'pytest-fusion-lock-…' name
  - Submits a Stripe sandbox PaymentIntent (no real charge)
  - Anchors to RVN testnet + IPFS + arlocal
"""

from __future__ import annotations

import os
import time
import uuid

import pytest

from lib import fusion_mocks, lock_flow, witness


def _live_lock_enabled() -> bool:
    return os.environ.get("SCRUPLE_RUN_LIVE_LOCK_TEST") == "1"


@pytest.fixture
def doc_with_unique_name():
    app = fusion_mocks.MockApp()
    app.activeDocument.design.name = (
        f"pytest-fusion-lock-{int(time.time())}-{uuid.uuid4().hex[:6]}"
    )
    return app


@pytest.mark.skipif(
    not _live_lock_enabled(),
    reason="Skipping live lock test; set SCRUPLE_RUN_LIVE_LOCK_TEST=1 to enable",
)
def test_full_lock_flow(live_client, doc_with_unique_name):
    """End-to-end: witness x3 → Stripe sandbox → chain-lock-pinned → Attributes."""
    design = doc_with_unique_name.activeDocument.design
    pid = witness.ensure_project_bound(design, live_client)

    # 3 witnesses
    for i in range(3):
        resp = witness.export_and_witness(design, live_client, pid, trigger=f"lock-test-{i}")
        assert resp["ok"] is True

    # We need a cookie for stripe-test-pay (the helper authenticates via
    # SCRUPLE_SESSION env var). Pass through what's already in the env.
    cookie = os.environ.get("SCRUPLE_SESSION")
    if not cookie:
        pytest.skip("SCRUPLE_SESSION cookie required for stripe-test-pay subprocess")

    pi_id = lock_flow.run_dev_stripe_pay(pid, action="chain-lock-pinned", cookie_value=cookie)
    assert pi_id.startswith("pi_")

    # Lock
    state = lock_flow.lock_and_anchor(
        design=design,
        client=live_client,
        project_id=pid,
        payment_intent_id=pi_id,
        tier="pinned",
        poll_timeout_seconds=120,
    )

    assert state.get("scr_id") or state.get("scrId")
    assert design.attributes.itemByName("Scruple", "scr_id") is not None
    # All three anchors should be populated for tier=pinned. The /api/lock/chain
    # synchronous response uses these field names:
    #   proofTxId / proofChain (RVN testnet asset issuance)
    #   ipfsCid                (IPFS pin)
    #   arweaveTxId            (Arweave anchor)
    has_rvn = bool(state.get("proofTxId") or state.get("rvn_txid") or state.get("rvnTxid"))
    has_ipfs = bool(state.get("ipfsCid") or state.get("ipfs_cid"))
    has_ar = bool(state.get("arweaveTxId") or state.get("arweave_uri") or state.get("arweaveUri"))
    assert has_rvn, f"missing RVN anchor in lock response: {state}"
    assert has_ipfs, f"missing IPFS anchor in lock response: {state}"
    assert has_ar, f"missing Arweave anchor in lock response: {state}"
