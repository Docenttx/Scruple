# Scruple Fusion 360 Add-In — Build Plan

**Date:** 2026-06-29
**Goal:** Ambient cryptographic provenance inside Autodesk Fusion 360, terminating in a three-anchor public-ledger lock (RVN testnet + IPFS + Arweave) and a court-ready receipt. Same witness pipeline already proven by the Stay Puft and SD 1.5 demos.

---

## Locked architectural decisions

- **Option 2 chosen.** The Fusion palette loads scruple-web's existing React UI directly via Fusion's embedded Qt WebEngine. Zero UI duplication; every feature added to scruple.ai becomes a Fusion feature for free.
- **Ambient auto-witness** on a configurable timer (default 5 min) + `documentSaved` event hook. User models normally; provenance accumulates silently.
- **Per-document project binding** via `design.attributes` — the scruple-web project ID is embedded in the Fusion document so the chain survives close/reopen.
- **Payment handoff** to the user's system browser via custom URL scheme. No Stripe Elements in the palette (Stripe-discouraged + CORS-sensitive).
- **OAuth login handoff** to the system browser via the palette's navigation-intercept event, returning via the same custom URL scheme.
- **One scruple-web instance** serves browser, Fusion, and future plugin hosts.

## Required inputs (all confirmed in this session)

- scruple-web at `/data/scruple-web` on `feature/pivot` ✓
- Witness server at `/opt/scruple-witness/server.js` (`:5799`) ✓
- arlocal + IPFS Kubo + RVN testnet ✓
- Stripe sandbox keys in scruple-web `.env.local` ✓
- Mac or Windows desktop with a current Fusion 360 install (user-side, **Phase 5 only**)

---

## Phase 0 — Oracle-side foundations (no Fusion required)

### 0.1 Repo skeleton
`/data/scruple-fusion/` populated with:
- `ScrupleFusion.py` — main add-in lifecycle (stub)
- `ScrupleFusion.manifest` — Fusion add-in metadata JSON
- `lib/scruple_client.py` — HTTP client targeting scruple-web (stdlib `urllib` only, no `requests`)
- `lib/fusion_mocks.py` — mock `adsk.core` / `adsk.fusion` surface for pytest
- `tests/` — pytest harness
- `palette_dev/` — local React-dev shell for palette UI iteration
- `README.md`, `BUILD_PLAN.md`

### 0.2 scruple-web `/embed/fusion` endpoint
New route at `app/embed/fusion/page.tsx`:
- Narrow + tall layout (target 400 × 800 px palette)
- No top nav (palette has its own Fusion chrome)
- Project picker + iteration grid + status pill + "Witness now" + "Lock & Anchor" buttons
- Reads `?project_id=…` query param to pre-select
- Auth via API key (header `Authorization: Bearer <key>`) OR NextAuth cookie

### 0.3 API key auth path
New migration:
- Table `api_keys (id, user_id, key_hash, scopes_json, created_at, expires_at, last_used_at, label)`
- `POST /api/auth/keys` — issue
- `DELETE /api/auth/keys/<id>` — revoke
- Middleware on `/api/*` accepts either NextAuth cookie OR `Authorization: Bearer <key>`

Reason: desktop apps don't reliably maintain browser sessions. API keys are the desktop pattern (GitHub Desktop, Linear, Figma plugins).

### 0.4 Custom URL scheme `scruple-fusion://`
- macOS: `Info.plist` URL types declaration in the add-in bundle
- Windows: registry entries under `HKCU\Software\Classes\scruple-fusion\`
- Add-in opens a fallback local HTTP listener on `127.0.0.1:<random>` for OSes where scheme registration fails

### 0.5 Mock-Fusion test harness
`tests/test_witness_flow.py` against live scruple-web on `:3001`:
- Mocked `design.attributes` + mocked `exportManager.execute()` (writes a fixed test `.f3d` from `tests/fixtures/`)
- Calls add-in's witness function
- Asserts `/api/runs` received correct shape
- Asserts `leaf_hash` returned
- Runs 5× sequentially, asserts `prev_record_hash` chain advances

`tests/test_lock_flow.py`:
- Builds a project with 5 mocked iterations
- Calls add-in's lock function
- Asserts Stripe sandbox PaymentIntent + `POST /api/lock/chain` flow
- Asserts `scrId` returned + correct Attributes written to mock document

**Deliverable:** repo skeleton + `/embed/fusion` route + API key auth + tests green on Oracle.
**Exit:** `pytest /data/scruple-fusion/tests/` returns 100% pass against live scruple-web.

---

## Phase 1 — Ambient witness pipeline

### 1.1 Witness client
`lib/scruple_client.py` wraps:
- `create_project(name, kind='cad') → project_id`
- `post_iteration(project_id, output_hash, prompt, input_artifacts) → witness_response`
- `get_project(project_id) → state_dict`
- `lock_chain(project_id, payment_intent_id, tier='pinned') → lock_response`

Stdlib only. JSON via `json` module. HTTP via `urllib.request`.

### 1.2 Export → hash → witness
`witness_save(design, project_id)`:
1. Generate temp path `tempfile.gettempdir() / 'scr_<uuid>.f3d'`
2. `design.exportManager.execute(createFusionArchiveExportOptions(tmp, design.rootComponent))`
3. SHA-256 the bytes (streamed, 1 MiB chunks)
4. `scruple_client.post_iteration(...)`
5. `os.unlink(tmp)`
6. Return response

### 1.3 Per-document project binding
On first witness for a document:
- `design.attributes.itemByName('Scruple', 'project_id')` → if `None`:
  - `scruple_client.create_project(name=document.name)`
  - `design.attributes.add('Scruple', 'project_id', str(project_id))`
- Else: reuse the id

Persists across sessions because Fusion serializes Attributes with the document.

### 1.4 Background timer thread
`auto_witness_loop()`:
- `threading.Thread(daemon=True)`
- Loop: `time.sleep(interval)`; if document is dirty since last witness → marshall witness call onto Fusion's UI thread via `app.fireCustomEvent('scruple_witness_tick')`
- Stop signal: `threading.Event()`

### 1.5 documentSaved event hook
- `app.documentEvents.documentSaved.add(handler)`
- On save event: immediate witness; reset timer

**Deliverable:** ambient witness pipeline tested.
**Exit:** mock harness simulates 10 saves over 5 mocked minutes → 10 chained leaves land in real scruple-web project.

---

## Phase 2 — Palette UI

### 2.1 `/embed/fusion` React page
Build on top of existing scruple-web components:
- Project picker (uses existing `ProjectList` component, narrowed)
- Live iteration counter (polls `/api/projects/<id>` every 30 s)
- Last leaf hash + recent leaves list (top 5)
- Action buttons: "Witness now" + "Lock & Anchor"
- Status pill: green (healthy) / amber (retrying) / red (disconnected)
- Footer link "Open full dashboard" → opens system browser to scruple.ai

### 2.2 Palette mount
`ui.palettes.add(id='scruple_main', name='Scruple', htmlFileURL='https://app.scruple.ai/embed/fusion?project_id=…', isVisible=True, showCloseButton=True, isResizable=True, width=400, height=800, useNewWebBrowser=True)`. Dock right side by default.

### 2.3 Python ↔ JS bridge
- Python → JS: `palette.sendInfoToHTML(action, json_string)`
- JS → Python: `palette.incomingFromHTML` event handler
- Used for: project change, witness-now trigger, lock trigger, payment-completion callback

### 2.4 Real-time updates
v1: poll `/api/projects/<id>` every 30 s.
v2: SSE via `/api/projects/<id>/events` (server-side event stream).
Keep v1 for MVP; SSE is a later refinement.

### 2.5 OAuth login intercept
Hook the palette's navigation event:
- If URL matches `accounts.google.com/*`, `appleid.apple.com/*`, or any non-scruple origin: **cancel** + `webbrowser.open(url)` system browser
- scruple-web's `/login` flow redirects on success to `scruple-fusion://auth-success?token=<api_key>`
- Custom URL handler in Python catches → posts to palette via `sendInfoToHTML('auth_token', token)`
- React UI stores token in local storage; subsequent fetches send `Authorization: Bearer <token>`

**Deliverable:** palette UI working against scruple-web.
**Exit:** real Chromium (or Brave) on Oracle loading `/embed/fusion`: login → project list → "Witness now" → leaf appears → "Lock" → 3-anchor lock → result displayed.

---

## Phase 3 — Lock & payment flow

### 3.1 Lock button → `/api/lock/chain`
React UI calls existing endpoint. For sandbox tier, the server handles Stripe sandbox internally (already proven). For production tier:
- `/api/lock/chain` returns `{ ok: false, paymentRequired: true, checkoutUrl: <stripe_session_url> }` instead of locking immediately
- React UI catches → fires `scruple-fusion://open-browser?url=<checkoutUrl>`

### 3.2 Stripe Checkout handoff
Python URL-scheme handler:
- Receives `open-browser` action
- `webbrowser.open(url)` system browser
- Palette enters "Waiting for payment…" state
- Polls `/api/projects/<id>` every 5 s
- When `project.status` flips to `chain_locked` or `persistent_locked`: refresh palette → shows lock result

Stripe webhook hits `/api/stripe/webhook` on scruple-web (existing).

### 3.3 Embed lock result in document
After lock confirmed via poll:
- `design.attributes.add('Scruple', 'scr_id', resp['scrId'])`
- `design.attributes.add('Scruple', 'merkle_root', resp['merkleRoot'])`
- `design.attributes.add('Scruple', 'lock_record_json', json.dumps(resp))`
- `design.attributes.add('Scruple', 'locked_at', resp['lockedAt'])`
- Palette shows: `Locked: SCR_XXX | Receipt: <url>` with copy buttons

**Deliverable:** full lock-via-palette flow.
**Exit:** Oracle Chromium → click Lock → Stripe sandbox → 3 anchors → palette shows result + Attributes confirmed in mock document.

---

## Phase 4 — Polish & UX

### 4.1 Settings dialog (Fusion Command Dialog)
- Auto-witness interval (slider 1-30 min, default 5)
- "Witness on save" toggle (default on)
- "Witness on idle for N min" toggle (default off)
- API base URL field (dev/staging/prod)
- API key field (paste here, or "Generate via browser" button → opens scruple.ai/settings/keys)

### 4.2 Marking menu items
- "Scruple → Witness now"
- "Scruple → Open dashboard" (system browser to scruple.ai project page)
- "Scruple → Lock & Anchor"

### 4.3 Retry queue + offline mode
- On `/api/runs` POST failure: append leaf JSON to `<addin_data>/queue.jsonl`
- On next successful witness: drain queue (POST queued leaves preserving order)
- Palette status pill: "N queued" badge when queue non-empty
- Exponential backoff: 5 s → 30 s → 2 min → 10 min → 30 min (cap)

### 4.4 Status-bar Progress Bar during witness POSTs
- `ui.progressBar.showBusy('Scruple: witnessing iteration #14')`
- Non-modal, lower-right corner
- Auto-clears on completion or failure

### 4.5 Error handling matrix
- Auth failure → palette shows "Sign in again" prompt
- Network failure → enter offline mode, queue events, retry with backoff
- Witness rejection (e.g., chain broken) → log to `<addin_data>/errors.log`, skip rather than break
- Lock failure → user notification with retry button + log
- Add-in crash → handlers retained, Fusion stays stable

**Deliverable:** production-grade UX, all edge cases handled.
**Exit:** stress test (close laptop mid-witness, kill network mid-lock, simulate witness server down) produces graceful failures, no data loss.

---

## Phase 5 — Desktop probes (user-side, irreducible)

Six standalone Python snippets. Each ~10-15 minutes user time. User pastes script into Fusion **Utilities → Scripts and Add-Ins → Scripts → Create New Script**, runs, copies TEXT COMMANDS console output, pastes back to me.

### Probe 5.1 — ExportManager headless
Confirm `.f3d` export from add-in code without user dialog. Test with: hand-built parametric model, imported STEP, model with linked subassembly. Output: filename + filesize for each.

### Probe 5.2 — documentSaved event
Hook the event, save the file, confirm event fires. Save again immediately, confirm event fires again. Modify file, wait 5+ min for recovery autosave, confirm event does **not** fire (validates our hypothesis that recovery ≠ documentSaved).

### Probe 5.3 — Background thread + Fusion API
Run a 30-second timer thread that pings `ui.progressBar.message = 'tick #N'` from the background thread. Confirm no crash. If it crashes, establishes that we must marshall via `app.fireCustomEvent`. If it works, threading is simpler.

### Probe 5.4 — Palette renders scruple-web React UI ⚠ load-bearing
Open palette with `ui.palettes.add(htmlFileURL='https://localhost:3001/embed/fusion?project_id=29', useNewWebBrowser=True)`. Confirm: React shell loads, project list renders, "Witness now" triggers a real witness, lock button triggers chain-lock flow.

If this works, Option 2 is green for production.
If it fails, fall back: build a native HTML palette (Option 3) — slower but no architectural blocker.

### Probe 5.5 — Browser handoff for payment
Trigger `webbrowser.open('https://localhost:3001/pay/test-session-id')`. Confirm system browser opens. Confirm custom URL scheme `scruple-fusion://test?ok=1` invokes the add-in's URL handler. Test on **both Mac and Windows**.

### Probe 5.6 — UI button registration
Confirm `Scruple` toolbar panel appears in `FusionSolidEnvironment` workspace. Three buttons render with icons. Marking menu items appear under right-click → "more."

**Deliverable:** six probes pass.
**Exit:** all green. Any failures triaged + fixed in Phases 0-4 then re-probed.

---

## Phase 6 (deferred) — Cloud verifier via Fusion Automation API

Long-term feature: third-party verifier doesn't need local Fusion. Uses Autodesk's Fusion Automation API (open beta, TypeScript, runs server-side on APS).

- 6.1 APS account + 2-legged OAuth + TypeScript SDK
- 6.2 Server-side verifier script (pulls `.f3d` from Fusion Team Hub URN, hashes, compares to RVN-anchored leaf)
- 6.3 scruple-web `/verify/<scrId>` endpoint that dispatches to APS

Defer past MVP. Adds enterprise verification story; not blocking individual creators.

---

## Phase Z — Packaging

- Final `manifest.json` with stable UUID + production icon assets (16/32/64 PNG)
- `README.md`: install instructions, troubleshooting, claim-boundary copy
- `LICENSE`
- `install.sh` / `install.bat` copying add-in into `~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/` (Mac) or `%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\` (Windows)
- Auto-update mechanism deferred to v1.1

---

## Risk register

| Risk | Likelihood | Mitigation |
|---|---|---|
| Fusion's embedded Chromium too old for our React UI | Medium | Probe 5.4 catches; fallback is native palette HTML (Option 3) — adds ~1 week |
| Custom URL scheme broken on some OS configs | Low | Local HTTP listener fallback (port-forwarded callback) |
| Background thread + Fusion API thread-safety issues | Medium | Probe 5.3; marshall via `fireCustomEvent` if needed |
| `.f3d` export blocks UI on large designs | Medium | Run export on background thread; status-bar progress |
| ExportManager doesn't follow linked components | Medium | Probe 5.1; fall back to Pack & Go (separate `.f3z` archive) for multi-doc |
| User Fusion version too old for Qt WebEngine palette | Low | Set min version in manifest; show clear upgrade prompt |
| Document Attribute size limit | Very Low | Lock record JSON ~2 KB; well under practical limits |
| CORS in palette breaks scruple-web | Medium | Designed around: all API calls same-origin via scruple-web proxy routes |
| Stripe Checkout opens in browser but user has no default | Very Low | Palette shows URL for manual copy |

## Out of scope

- Real-time multi-user collaboration provenance (Fusion Team co-editing)
- Generative Design body attestation (handled by Hard Scruple separately)
- CAM operation provenance (subset of timeline; same approach, deferred)
- Proving "what the user saw matches the file" (out of scope — see claim boundary)
- Auto-update / install-from-Autodesk-store (v1.1+)

## Claim boundary (preserved verbatim from the prior plan)

> "This exact exported file existed in this state at witness-time T, signed, and is unaltered since."

Not "this was not made by AI." Not "this was the entire process." Not "the live design will reproduce this hash." Implementation and marketing copy must stay behind that claim.

## Effort estimate

| Phase | Effort |
|---|---|
| 0 — Oracle foundations | 2-3 days |
| 1 — Ambient witness | 1-2 days |
| 2 — Palette UI | 2-3 days |
| 3 — Lock + payment | 2 days |
| 4 — Polish | 2 days |
| 5 — Desktop probes (you-side) | ~3 hours user + 1-2 days me on fixes |
| Z — Packaging | 1 day |
| **MVP (0-5 + Z)** | **~2 weeks me + ~3 hours you** |
| **6 — Cloud verifier (deferred)** | **+1 week** |

## Pickup order on day 1

1. Create `/data/scruple-fusion/` repo skeleton with stubs
2. Add API key auth migration to scruple-web (`/api/auth/keys`)
3. Mock-Fusion test harness running against live scruple-web on `:3001`
4. First failing test for witness flow → make it pass
5. From there, work down the phase list
