# Scruple for Fusion 360

Ambient cryptographic provenance for Autodesk Fusion 360 designs. Same
witness pipeline that produces the Scruple receipts you see at
`scruple.ai/receipt/<scr_id>` — embedded inside Fusion itself.

## Status

Pre-MVP. Phases 0-4 (Oracle-side) under construction. Phases 5 (desktop
probes) and Z (packaging) require a Mac or Windows workstation with
Fusion 360 installed.

## Architecture

- **Option 2 palette**: Fusion's Qt WebEngine palette loads scruple-web's
  React UI directly. Zero UI duplication.
- **Ambient witness**: every save + every N minutes (configurable),
  Fusion's active design is exported, hashed, and POSTed to scruple-web's
  witness server.
- **Per-document binding**: `design.attributes` carries the scruple-web
  project ID so the chain survives close + reopen.
- **Three-anchor lock**: same `/api/lock/chain` path as the canvas demos
  — Ravencoin testnet + IPFS + Arweave.

Full design in `BUILD_PLAN.md`. Public-facing copy in `WEBSITE_SECTION_DRAFT.md`.

## Layout

```
ScrupleFusion.py             Add-in entry point (Fusion calls run/stop)
ScrupleFusion.manifest       Fusion add-in metadata
lib/scruple_client.py        HTTP client targeting scruple-web (stdlib only)
lib/witness.py               Export + hash + witness logic
lib/auto_witness.py          Background timer thread
lib/palette_host.py          Palette mount + UI commands + URL scheme
lib/queue_store.py           Offline retry queue (Phase 4.3)
lib/fusion_mocks.py          Mock adsk surface for pytest
tests/                       pytest harness
palette_dev/                 Local React dev shell for palette UI iteration
resources/                   Icons + static assets
```

## Running tests

The pytest harness exercises the add-in against a live scruple-web
running on `http://127.0.0.1:3001`. Tests use the `lib/fusion_mocks.py`
surface in place of `adsk.core` / `adsk.fusion`.

```bash
# 1. start scruple-web in another shell:
cd /data/scruple-web && PORT=3001 npm run dev

# 2. issue an API key (one-time per dev session):
#    POST /api/auth/keys (cookie or admin path); export it:
export SCRUPLE_API_KEY=sk_test_xxx
export SCRUPLE_BASE=http://127.0.0.1:3001

# 3. run tests:
cd /data/scruple-fusion
pytest tests/ -v
```

## Install (desktop)

Phase Z — packaging hasn't shipped yet. For testing the manifest on a
real Fusion install, copy this directory into:

- **macOS**: `~/Library/Application Support/Autodesk/Autodesk Fusion 360/API/AddIns/`
- **Windows**: `%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\`

Then in Fusion: **Utilities → Scripts and Add-Ins → Add-Ins → ScrupleFusion → Run**.

## Claim boundary

> This exact exported file existed in this state at witness-time T, signed,
> and is unaltered since.

Not "this was not made by AI." Not "this was the entire process." Not
"the live design will reproduce this hash." Implementation and marketing
copy stays behind that claim.
