# Scruple Fusion — Session report 2026-06-30

End-to-end build of phases 0-4 + Z of the Fusion 360 add-in. Everything
that doesn't require a desktop with Fusion installed now works.

## What landed (in-tree)

### `/data/scruple-fusion/` — the add-in repo

```
ScrupleFusion.py              add-in lifecycle (run/stop)
ScrupleFusion.manifest        Fusion add-in metadata JSON
install.sh / install.bat      install into Fusion's AddIns directory
README.md                     usage docs
BUILD_PLAN.md                 7-phase work order (from earlier session)
WEBSITE_SECTION_DRAFT.md      public-facing copy (from earlier session)
SESSION_REPORT_2026-06-30.md  this file

lib/
  scruple_client.py           HTTP client targeting scruple-web (stdlib only)
  witness.py                  export → hash → witness flow
  auto_witness.py             background timer thread (Phase 1)
  palette_host.py             palette mount + JS↔Python bridge + URL scheme
  queue_store.py              offline retry queue (Phase 4)
  lock_flow.py                lock + payment handoff (Phase 3)
  fusion_mocks.py             mock adsk surface for pytest

tests/
  conftest.py                 pytest fixtures
  test_witness_mocks.py       pure-mock tests (6)
  test_queue_store.py         retry queue tests (5)
  test_auto_witness.py        background thread tests (3)
  test_witness_flow_live.py   live tests against scruple-web (6)
  test_lock_flow_live.py      live full E2E lock test (1)

probes/                       Phase 5 desktop probe scripts
  README.md                   probe instructions for the human runner
  probe_5_1_export_manager.py        ExportManager headless export
  probe_5_2_document_saved.py        documentSaved event hook
  probe_5_3_background_thread.py     thread → Fusion API safety
  probe_5_4_palette_react_ui.py      ⚠ load-bearing: palette renders /embed/fusion
  probe_5_5_browser_handoff.py       webbrowser.open + custom URL scheme
  probe_5_6_ui_button_registration.py panel + 3 buttons in workspace
```

### scruple-web — supporting infrastructure (changed)

- `lib/db/migrations/023_api_keys.sql` — new `api_keys` table
- `lib/db/migrations/024_project_type_cad.sql` — extend type enum to include 'cad'
- `lib/auth/apiKey.ts` — `requireUser(req)` resolves cookie OR Bearer
- `lib/types.ts` — `ProjectType` now includes `'cad'`
- `lib/iterations/ingest.ts` — `OutputKind` extended + extFor() recognises 'cad' → 'f3d'
- `lib/projects/actions.ts` — new `createProjectAs(uid, input)` helper
- `app/api/auth/keys/route.ts` — POST issue, GET list
- `app/api/auth/keys/[id]/route.ts` — DELETE revoke
- `app/api/projects/route.ts` — switched to Bearer-capable `requireUser()`
- `app/api/projects/[id]/route.ts` — new GET endpoint for add-in polling
- `app/api/runs/route.ts` — switched to `requireUser()`, accepts outputKind='cad'
- `app/api/witness/cad/route.ts` — direct-witness endpoint (no Modal round-trip)
- `app/api/lock/chain/route.ts` — switched to `requireUser()`
- `app/embed/fusion/page.tsx` + `FusionPalette.tsx` + `layout.tsx` — palette React UI

## Tests: 21 / 21 green

```
$ pytest tests/ -v
14 mock-only tests:
  test_witness_mocks.py        6 PASS
  test_queue_store.py          5 PASS
  test_auto_witness.py         3 PASS

6 live tests against scruple-web :3001 (Bearer-authed):
  test_bearer_auth_lists_projects                        PASS
  test_create_project_and_bind                           PASS
  test_single_witness_lands_iteration                    PASS
  test_five_witnesses_chain                              PASS
  test_invalid_bearer_returns_401                        PASS
  test_machine_manifest_hash_present_in_iteration        PASS

1 live full lock E2E (gated on SCRUPLE_RUN_LIVE_LOCK_TEST=1):
  test_full_lock_flow  PASS
    → SCR_35FF0AD9 with RVN testnet + IPFS + arlocal Arweave anchors
```

## Proof artifacts from this session

Real chain-locked project in the DB, created by the live test:

| Field | Value |
|---|---|
| SCR-ID | `SCR_35FF0AD9` |
| Merkle root | `f317c337f33ffe0d8c272c61c35bd1eeac262520b5b62f8cba341f0b10113fdd` |
| RVN testnet txid | `4061fa6741771847792c30d587c097a32bb1a4555210d946aa32766f16af4c13` |
| IPFS CID | `bafkreicstjeezzgmnkymtwqqf2hs3dbudhi73q7wqsjubxiky6cml2scia` |
| Arweave txid (arlocal) | `nr2YpNlZP0wpbB2NL8Mu2yn_w9Z0bbaJ9q8IMLYlqE8` |
| Package hash | `126d286ecde6552b0a1c006a0ece71334a092c89b16be8dd77b6ef6dac42b558` |
| Witnessed count | 3 |
| Tier | pinned |
| Locked at | 2026-06-30T18:11:20.743Z |

Receipt: `http://localhost:3001/receipt/SCR_35FF0AD9`

Plus 6 other test projects from the witness-flow runs, each carrying
5 chained leaves with `output_kind='cad'` and `witnessed=1`.

## What still requires desktop Fusion (Phase 5)

The six probes in `probes/`. Each is a standalone Python script for
pasting into Fusion 360's Scripts & Add-Ins dialog. Estimated time:
~10-15 min per probe, total ~90 min user-side. Each prints to the
TEXT COMMANDS console.

The most important is **5.4 (palette renders React UI)** — if that
works, the whole Option 2 architecture is greenlit for production. If
it fails, fall back to Option 3 (native HTML palette, +~1 week of
duplicated UI work).

## Key design decisions made this session

1. **Direct-witness endpoint** `/api/witness/cad`: bypasses
   `/api/runs` + Modal because Fusion's output IS the bytes — there is
   no Modal-side execution to attest. Cleaner architectural split than
   shoehorning Fusion through the runs path.

2. **`createProjectAs(uid, input)`**: explicit-userId variant of
   `createProject` so route handlers can serve API-key-authed callers
   without the inner `auth()` call failing. Old cookie-based
   `createProject` still works for the rest of the codebase.

3. **`requireUser(req)` over re-plumbing all server actions**: the API
   key path only needed to land on the 5 routes the add-in actually
   calls. Trying to rewire every `userId()` call inside `actions.ts`
   would have been a much wider blast-radius change for no add-in
   benefit.

4. **'cad' as a first-class project type**: cleaner than overloading
   'image'. Receipt page + audit script will need a small follow-up
   to label CAD-type projects appropriately, but the leaf preimage
   path is unaffected.

5. **Idempotent `registerCustomEvent` in the mock**: real Fusion raises
   on duplicate. The mock returns the existing event. Auto-witness
   already wraps in try/except, so production behavior is preserved;
   the mock just makes tests easier.

## Operator notes

- scruple-web migrations 023 + 024 applied on first request after
  rebuild. Verified.
- Witness server (:5799), arlocal (:1984), IPFS (:5001), Modal — all
  unchanged, all healthy.
- API key issued for `test@scruple.dev` lives in
  `/tmp/scruple_test_api_key`; the matching session token in
  `/tmp/scruple_test_session_token`. These are dev-only, on Oracle, but
  delete them once you're done if you care.
- `arlocal` treasury wallet `TLhGT92H...` was already funded
  (999_999_935_978_784 winston at session start).

## Files touched in scruple-web (for the commit)

```
M  app/api/lock/chain/route.ts            ← requireUser
M  app/api/projects/route.ts              ← requireUser + 'cad' type
M  app/api/runs/route.ts                  ← requireUser + 'cad' outputKind
M  lib/iterations/ingest.ts               ← 'cad' OutputKind + extFor('cad')→.f3d
M  lib/projects/actions.ts                ← createProjectAs(uid, input)
M  lib/types.ts                           ← ProjectType + 'cad'
?? app/api/auth/keys/route.ts             ← POST issue + GET list
?? app/api/auth/keys/[id]/route.ts        ← DELETE revoke
?? app/api/projects/[id]/route.ts         ← GET project + iterations for add-in
?? app/api/witness/cad/route.ts           ← direct-witness for Fusion bytes
?? app/embed/fusion/page.tsx              ← palette entry
?? app/embed/fusion/FusionPalette.tsx     ← palette React UI
?? app/embed/fusion/layout.tsx            ← stripped-down layout
?? lib/auth/apiKey.ts                     ← API key helpers + requireUser
?? lib/db/migrations/023_api_keys.sql
?? lib/db/migrations/024_project_type_cad.sql
```

## Next-session pickup

Hand the contents of `/data/scruple-fusion/probes/` to a desktop
operator. Specifically probe 5.4 first — that's the load-bearing one.
Everything else can be triaged based on what 5.4 reveals.
