# Scruple Fusion — overnight build, 2026-06-30 PM

While you were out: closed the three biggest gaps surfaced during the
desktop test session. Everything below is committed + live on
`https://scruple.stooges.ai`. Pytest 21/21 still green after all changes.

## What's wired now that wasn't this afternoon

### 1. Auto-mint signin — no more API-key paste

The palette is now end-user-shaped:
- **No token in URL or localStorage** → palette shows a single big
  **"Sign in with Scruple"** button.
- Clicking it navigates the palette to `/api/auth/keys/fusion-mint?next=/embed/fusion`.
- That endpoint: if you're not signed in, bounces through `/login` first;
  once you have a cookie session, mints a fresh API key labeled
  `fusion-addin (2026-06-30)`, redirects back to `/embed/fusion?token=<key>`.
- Palette reads the token from URL, stores in `localStorage`, signs in.
- Developer can still paste a key directly via a `<details>` disclosure
  at the bottom.

The wrong-Google-account problem you hit earlier: solved. The login page
now honors `callbackUrl` so the post-signin destination is preserved.
To switch accounts: `/api/auth/signout` then sign in again with whatever.

### 2. Autodesk SSO — scaffolded, ready for your APS app registration

You asked about tying signin to Autodesk login. Both halves are coded:

- **NextAuth provider** for Autodesk added to `lib/auth/auth.ts`. APS v2
  endpoints, openid + user-profile:read scopes, standard profile mapping.
  Conditionally included if `AUTODESK_CLIENT_ID` + `AUTODESK_CLIENT_SECRET`
  are set in `.env.local` — gracefully absent if not.
- **"Sign in with Autodesk"** button on `/login`, shown above Google when
  the provider is configured.

**What you need to do (one-time, ~15 minutes):**
- See `AUTODESK_SSO_SETUP.md` (committed in scruple-fusion repo).
- Register Scruple as a Web App at https://aps.autodesk.com/myapps.
- Callback URL: `https://scruple.stooges.ai/api/auth/callback/autodesk`
- Scopes: `user-profile:read openid`
- Paste the Client ID + Secret into `/data/scruple-web/.env.local`, restart.

Once you do that, every Fusion user sees "Sign in with Autodesk" as the
primary CTA and inherits their Autodesk identity.

### 3. JS↔Python bridge — palette buttons now actually do things

The palette ↔ Fusion Python bridge is fully wired:

| Palette → Python | What Python does |
|---|---|
| `set_api_key` | Caches the bearer token in shared state |
| `project_changed` | Tracks the selected project |
| `witness_now` | Runs `design.exportManager.execute()` → POST `/api/witness/cad` |
| `lock_chain` | Drives test-pay → POST `/api/lock/chain` → writes SCR-ID to `design.attributes` |
| `open_browser` | `webbrowser.open()` with relative→absolute URL handling |

| Python → Palette | What React does |
|---|---|
| `witness_started/done/error` | Updates busy state, refreshes detail, surfaces errors |
| `lock_started/done/error` | Same |

Auto-witness loop ALSO now actually witnesses: the daemon thread fires
a custom event every 5 minutes (if dirty), the UI-thread handler runs
the real export + POST.

`documentSaved` event hooks through the same chokepoint — every save
fires a witness.

### 4. Misc bug fixes from the session

- **`install.bat`** no longer breaks on paths with spaces. The classic
  `%~dp0` + closing-quote escape issue. Fixed by stripping trailing `\`.
- **Embed layout** no longer emits a second `<html>`/`<body>` — that was
  the React hydration error you saw in Fusion's Chromium.
- **"Open dashboard"** navigates the palette in-place (no system-browser
  handoff for this case). Stripe Checkout + Google/Autodesk OAuth still
  go to the system browser because those genuinely require it.

## What's at the server right now

| URL | What it serves |
|---|---|
| `https://scruple.stooges.ai/scruple-fusion-2026-06-30.zip` | Full add-in bundle (72 KB) — fresh build |
| `https://scruple.stooges.ai/ScrupleFusion.py` | Latest entry-point only |
| `https://scruple.stooges.ai/palette_host.py` | Latest palette host module |
| `https://scruple.stooges.ai/scruple_check.py` + `.manifest` | Diagnostic script |

## Three pickup paths when you're back

### Fastest — overwrite ScrupleFusion.py only

You already have most of the add-in. To test tonight's bridge wiring:

```powershell
Invoke-WebRequest -Uri "https://scruple.stooges.ai/ScrupleFusion.py" `
  -OutFile "$env:APPDATA\Autodesk\Autodesk Fusion 360\API\AddIns\ScrupleFusion\ScrupleFusion.py"
Remove-Item -Recurse -Force "$env:APPDATA\Autodesk\Autodesk Fusion 360\API\AddIns\ScrupleFusion\__pycache__" -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force "$env:APPDATA\Autodesk\Autodesk Fusion 360\API\AddIns\ScrupleFusion\lib\__pycache__" -ErrorAction SilentlyContinue
```

Then Shift+S → ScrupleFusion → Stop → Run. Try:
- "Open full dashboard in palette" → palette navigates to scruple.stooges.ai
- "Witness now" with a project selected → should run, show busy state, then update
- "Lock & Anchor" → drives the dev test-pay → 3-anchor lock → SCR-ID returns

### Clean — re-pull the bundle

```powershell
cd D:\ScrupleFusion
Remove-Item -Recurse -Force scruple-fusion-2026-06-30
Invoke-WebRequest -Uri "https://scruple.stooges.ai/scruple-fusion-2026-06-30.zip" -OutFile scruple-fusion-2026-06-30.zip
Expand-Archive -Force scruple-fusion-2026-06-30.zip scruple-fusion-2026-06-30
# Then reinstall via PowerShell robocopy (install.bat is fixed now but
# re-run also works):
$dst = "$env:APPDATA\Autodesk\Autodesk Fusion 360\API\AddIns\ScrupleFusion"
robocopy "D:\ScrupleFusion\scruple-fusion-2026-06-30" $dst /E /XD __pycache__ .pytest_cache tests palette_dev
```

### Real signin test

Once everything is in place, try the full real signin:

1. In Fusion: Shift+S → ScrupleFusion → Stop (clears the existing key cache)
2. In PowerShell, clear the stored token:
   ```powershell
   $localStorage = "$env:LOCALAPPDATA\Autodesk\Autodesk Fusion 360\Cache\…"
   # Actually localStorage is tied to the palette URL — simplest reset is
   # to navigate the palette to /embed/fusion (no token param) which will
   # show the signin button if localStorage is empty.
   ```
3. Shift+S → Run → palette shows "Sign in with Scruple"
4. Click → Fusion's embedded Chromium navigates to /login
5. Pick Google (or Autodesk once you set up APS) → sign in
6. Redirects back to /embed/fusion?token=<freshly-minted-key>
7. Palette transitions to project picker
8. From here, witness + lock should all work

## What I deferred for you to decide

- **Production Stripe Checkout for lock payment.** Right now the lock
  uses the dev test-pay path (admin-confirms the PI). For real users
  this needs the Stripe Checkout handoff via custom URL scheme — and
  that requires Probe 5.5 to confirm `scruple-fusion://` callbacks
  actually work on Windows. Not blocking the test loop tonight.
- **Toolbar buttons** (Probe 5.6) — still a stub. Adds a "Scruple" panel
  to the Design workspace with quick action buttons. Pure polish.
- **Settings dialog** — auto-witness interval slider, "Witness on save"
  toggle, etc. Mentioned in BUILD_PLAN.md Phase 4.1, not done.

## Commits landed tonight

- **scruple-web** `a3f8a88` — auto-mint signin + bridge wiring + Autodesk SSO + embed UX fixes (10 files, +956 / -68)
- **scruple-fusion** `258dd75` — Python bridge handlers + Autodesk SSO docs + install.bat fix (5 files, +610 / -38)

## Test status

```
21 / 21 pytest green against https://scruple.stooges.ai
  6 mock-only (witness, retry, auto-witness)
 14 live integration (Bearer auth + chained witnesses + queue)
  1 full chain-lock E2E (RVN testnet + IPFS + arlocal Arweave)
```

The integration tests run on the actual public URL with the
`scruple-fusion-addin/0.1.0` UA we pinned earlier.

Sleep well. See you when you're back.
