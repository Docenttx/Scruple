# Scruple Fusion 360 Add-In — Desktop Test Plan

End-to-end validation on a desktop with Fusion 360 installed. Designed to
be followed top-to-bottom by an operator with no prior context on the
add-in's internals. Estimated time: **~2 hours** total (15 min setup +
6 probes × 10-15 min + 30 min full E2E + reporting).

You produce one of three outcomes per step: **PASS** / **FAIL** / **PARTIAL**.
Report verbatim console output for FAIL and PARTIAL. PASS = move on.

---

## Prerequisites

- **macOS or Windows** with **Autodesk Fusion 360** installed and signed in.
  - Min version: 2.0.20999 or later (any 2024+ build is fine).
  - Confirm by: Fusion → top-right account menu → About Fusion 360.
- **A simple test design open in Fusion.** Doesn't matter what — extrude a
  rectangle on the XY plane and you're done. Save it with name
  `scruple-test-design.f3d` to a Fusion Team Hub project of your choice.
- **SSH access to the Oracle host** (or wherever scruple-web is running).
  Confirm by running `ssh ubuntu@<oracle-host>` and getting a shell.
- **A modern web browser** (Chrome, Firefox, Safari, or Edge) for the
  initial API key + cookie bootstrap.

If the Oracle host has been rebooted since the last session, also need:
- arlocal (`:1984`), IPFS Kubo (`:5001`), witness server (`:5799`)
  running. The witness server runs under pm2 (`pm2 list`); arlocal +
  IPFS are usually `systemctl` units. Check `/data/scruple-fusion/README.md`
  if you need to bring any of them back up.

---

## Phase A — Oracle-side setup (one-time, ~5 min)

### Step A1 — Confirm scruple-web is running

```bash
ssh ubuntu@<oracle-host>
curl -s -o /dev/null -w "%{http_code}\n" https://scruple.stooges.ai/api/health
```

**Expect:** `200`.

If `000` or anything else, start it:

```bash
cd /data/scruple-web && PORT=3001 npm run dev &
# wait ~5 seconds
sleep 5
curl -s https://scruple.stooges.ai/api/health
```

### Step A2 — Confirm the witness + anchor infra is up

```bash
curl -s http://localhost:5799/health                          # witness
curl -s http://localhost:1984/info | head -3                  # arlocal
curl -s -X POST http://localhost:5001/api/v0/id | head -c 80  # IPFS
```

All three should return JSON. If arlocal's treasury wallet is empty
(0 winston), refund:

```bash
ADDR="TLhGT92H-quX2nrNt2dPWxr4fCfLw8fleRJPb4mBCHo"
curl "http://localhost:1984/mint/$ADDR/1000000000000000" && curl "http://localhost:1984/mine"
```

### Step A3 — Issue an API key (one-time per test session)

```bash
SECRET="662651ecc4f1375d82496ca505720bf123b9a67c9a0f38c5"
SESS_JSON=$(curl -s "https://scruple.stooges.ai/api/dev/session?email=test@scruple.dev&secret=$SECRET")
TOKEN=$(echo "$SESS_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["sessionToken"])')
COOKIE="__Secure-authjs.session-token=$TOKEN"

KEY_RESP=$(curl -s -X POST -H "Cookie: $COOKIE" -H "Content-Type: application/json" \
  -d '{"label":"desktop-fusion-test"}' \
  https://scruple.stooges.ai/api/auth/keys)
echo "$KEY_RESP" | python3 -c 'import json,sys; print(json.load(sys.stdin)["plaintext"])'
```

**Expect:** A string starting with `sk_test_…` printed to your terminal.

**Save this string somewhere — you'll paste it into the add-in later.**

> Production note: in real-user installs, the user would issue this key
> via the scruple.ai web UI (Settings → API Keys). For testing we use
> the dev backdoor since there's no production UI yet.

---

## Phase B — Confirm the public URL works (~30 sec)

The add-in talks to `https://scruple.stooges.ai` over real HTTPS —
the same Cloudflare tunnel the ComfyUI canvas at `canvas.stooges.ai`
already uses. **No SSH tunnel needed.**

### Step B1 — Smoke test from your desktop

```bash
curl -s https://scruple.stooges.ai/api/health
```

**Expect:** `{"ok":true,...}`.

### Step B2 — Smoke test with your API key

```bash
KEY="sk_test_…"   # paste the key from Step A3
curl -s -H "Authorization: Bearer $KEY" https://scruple.stooges.ai/api/projects | head -c 200
```

**Expect:** `{"projects":[…],"activeId":null,"count":…}`.

If you get `{"error":"Unauthorized"}`, the key didn't transmit
correctly — re-issue per Step A3.

---

## Phase C — Install the add-in (~5 min)

### Step C1 — Get the add-in onto your desktop

Easiest: clone or copy `/data/scruple-fusion` from the Oracle host.

```bash
# from your desktop:
mkdir -p ~/scruple-fusion
rsync -av --exclude='__pycache__' --exclude='.pytest_cache' \
  ubuntu@<oracle-host>:/data/scruple-fusion/ ~/scruple-fusion/
```

### Step C2 — Install into Fusion's AddIns directory

**macOS:**
```bash
cd ~/scruple-fusion
./install.sh --link
```

**Windows (PowerShell):**
```powershell
cd $HOME\scruple-fusion
.\install.bat
```

The `--link` flag on macOS symlinks so you can hot-edit the add-in
files. Windows doesn't have a `--link` mode in the installer; if you
want symlink-style behavior, run `mklink /D` manually.

### Step C3 — Register the add-in with Fusion

1. Open Fusion 360.
2. Shift+S (or **Utilities → Scripts and Add-Ins**).
3. Click the **Add-Ins** tab (not Scripts).
4. **ScrupleFusion** should appear in the list. If it doesn't, click
   the **+** icon and point it at `~/scruple-fusion/` (the directory
   containing `ScrupleFusion.manifest`).
5. Click **Run**.

**Expect:** A "Scruple" palette appears docked on the right side of
the modeling view, showing the API-key entry form.

If the palette is blank, see **Probe 5.4 — Diagnosing palette failures**
below.

### Step C4 — Paste your API key into the palette

Paste the `sk_test_…` string from Step A3 into the password field at
the bottom of the palette. Press Enter.

**Expect:** Palette transitions to the project picker view.

---

## Phase D — Run the probes in order (~75 min total)

Run each probe via: **Utilities → Scripts and Add-Ins → Scripts tab →
Create New Script → paste contents → Run**. The probe files live in
`~/scruple-fusion/probes/`.

For each probe, report back:

```
=== PROBE 5.X ===
Fusion version:     <e.g., 2.0.21127>
OS:                 <macOS 14.5 / Windows 11 23H2>
Result:             pass | fail | partial
Console output:
<copy/paste verbatim from TEXT COMMANDS panel — usually bottom of Fusion>
Notes:              <anything surprising or visual>
```

To see the TEXT COMMANDS panel: **View menu → Show Text Commands**.

---

### Probe 5.4 — Palette renders React UI ⚠ RUN THIS FIRST

**This is load-bearing.** If it fails, the entire Option 2
architecture is wrong and we need to fall back to native HTML palette
(Option 3, ~1 week of rework).

1. Open `~/scruple-fusion/probes/probe_5_4_palette_react_ui.py` in any
   text editor.
2. Find the line:
   ```python
   EMBED_URL = "https://scruple.stooges.ai/embed/fusion?token=REPLACE_WITH_YOUR_KEY"
   ```
3. Replace `REPLACE_WITH_YOUR_KEY` with your `sk_test_…` value from A3.
   The final URL should look like:
   `https://scruple.stooges.ai/embed/fusion?token=sk_test_Ct1HNZzpcIvY…`
4. Copy the entire script. In Fusion: Scripts and Add-Ins → Scripts
   tab → **Create New Script** → name it `probe_5_4` → click the
   pencil icon to open the editor (uses VS Code on macOS, Spyder on
   Windows by default) → paste → save → click Run.

**Look for:**
- A new palette titled "Scruple Probe" appears.
- Dark background renders inside the palette.
- "Scruple for Fusion" header text visible at the top.
- Project picker dropdown populates (may show "— select —" if you
  have no projects; that's fine).
- "Witness now" + "Lock & Anchor" buttons appear at the bottom.

**Report:**
- PASS: all five visual checks tick.
- PARTIAL: palette opens but some elements blank / missing.
  Screenshot the palette and send it back.
- FAIL: palette never opens, or opens but is completely blank, or
  Fusion shows a "WebEngine error" dialog.

**If FAIL:** the embedded Chromium can't reach our React app. Most
likely cause: stale `useNewWebBrowser` flag or Fusion's bundled
Chromium too old. Try opening `https://scruple.stooges.ai/embed/fusion?token=<your-key>`
in your system browser — confirm it renders there. If it does, the
problem is Fusion's WebEngine, not our code.

---

### Probe 5.1 — ExportManager headless

Validates that `design.exportManager.execute()` writes an `.f3d`
without showing any dialog or interrupting the user.

1. Have a **parametric model** open (anything with at least one
   extruded body).
2. Paste `~/scruple-fusion/probes/probe_5_1_export_manager.py` into a
   new Script. Run.
3. **Look for:** A line in TEXT COMMANDS like
   `PROBE 5.1 PASS  filename: /var/folders/.../scruple_probe_5_1_*.f3d  size: ###### bytes  duration: ### ms`.
4. **Repeat the run** with:
   - An **imported STEP** model open (File → Open → pick any .step or
     .stp file you have lying around).
   - A model that **links a subassembly** (insert a Fusion Team
     component into your design as a linked occurrence).

Report the output for **all three** scenarios. If any of the three
fails or shows a dialog, that's a failure mode we need to design
around.

---

### Probe 5.2 — documentSaved event

Validates that we can hook `documentSaved` and that recovery autosave
does NOT trigger it.

1. Make sure your test design is **dirty** (modify a sketch or
   parameter so the title bar shows the unsaved indicator).
2. Paste `probe_5_2_document_saved.py` into a new Script. Run.
3. A dialog should appear: "Probe 5.2 armed."
4. **Click OK.**
5. Press **Cmd+S** (macOS) or **Ctrl+S** (Windows). In TEXT COMMANDS,
   look for `[probe 5.2] documentSaved fired at t=…`.
6. Press **Cmd+S** again immediately. Confirm a second fire.
7. **Now make a small edit, then wait 6+ minutes** without saving.
   Watch TEXT COMMANDS. **No** `[probe 5.2]` line should appear.
8. After waiting, in Scripts and Add-Ins click **Stop** on this
   script. Report the summary line.

**Expect:** 2 explicit-save fires, 0 recovery-autosave fires.

If recovery autosave DOES fire `documentSaved`, that breaks our
plan to deduplicate witnesses — we'd witness on autosave too,
inflating leaf counts. Flag immediately.

---

### Probe 5.3 — Background thread + Fusion API safety

Validates whether Python threads can call Fusion APIs directly. If
not, we must marshal calls onto the Fusion API thread via
`fireCustomEvent`.

1. Paste `probe_5_3_background_thread.py` into a new Script. Run.
2. Dialog: "Probe 5.3: starting background thread for 30 seconds."
   Click OK.
3. Watch TEXT COMMANDS for `[probe 5.3] bg thread tick #N` lines.
4. If Fusion **freezes or crashes** during the 30 seconds, note the
   last tick number you saw before the freeze.
5. After 30 seconds, click **Stop** on the script.

**Report:**
- PASS: 15 ticks logged cleanly, Fusion responsive throughout.
- PARTIAL: ticks logged but some have EXCEPTION traces — copy the
  trace verbatim.
- FAIL: Fusion froze / crashed / OS asked to force-quit. Last tick
  number is your evidence.

If FAIL or PARTIAL, the production add-in needs to marshal all
witness calls through `app.fireCustomEvent` — already handled in
the `lib/auto_witness.py` design. The probe just confirms which
behavior we need.

---

### Probe 5.5 — Browser handoff + custom URL scheme

Validates payment + auth-callback round-trip.

1. Paste `probe_5_5_browser_handoff.py` into a new Script. Run.
2. **Half A:** scruple.ai should open in your system browser.
   - Report: did it open? Which browser?
3. **Half B:** A dialog will mention `scruple-fusion://test?probe=…`.
   - macOS: a system prompt should ask whether to open ScrupleFusion
     (or whatever app is registered for the scheme). If no scheme
     handler is registered, the system browser will show "address not
     valid."
   - Windows: similar — a UAC-style prompt about opening with an app.
4. **Fallback test:** the script also prints a
   `http://127.0.0.1:<port>/callback?probe=5_5&fallback=1` URL. Paste
   it into your browser. Watch TEXT COMMANDS for a
   `[probe 5.5] callback: {…fallback=1…}` line.
5. After 60 seconds, the script prints `PROBE 5.5 PASS|FAIL` summary.
   Click Stop.

**Report:**
- Did scruple.ai open in browser? (yes/no)
- Did the `scruple-fusion://` prompt appear? (yes/no — failure is
  expected if install.sh / install.bat didn't register the scheme,
  which they currently don't on most setups)
- Did the local-listener fallback receive the callback? (yes/no)

The local-listener fallback is the production safety net. The custom
scheme is the polished path. If the listener works, we ship; if not,
that's a real blocker.

---

### Probe 5.6 — UI button registration

Validates that we can add a toolbar panel with command buttons to
the Design workspace.

1. Make sure you're in the **Design** workspace (top-left workspace
   selector).
2. Paste `probe_5_6_ui_button_registration.py` into a new Script. Run.
3. Dialog: "Probe 5.6: a 'Scruple Probe' panel should now be in your
   Design workspace." Click OK.
4. **Look at the toolbar** (top of the modeling view). You should see
   a panel labeled **Scruple Probe** with three buttons:
   "Witness now", "Lock & Anchor", "Open dashboard".
5. Click each button. Fusion will show a "no command handler attached"
   error — that's expected, this probe only registers the buttons,
   not the click handlers.

**Report:**
- Panel visible: yes/no
- All 3 buttons visible: yes/no
- Did clicking show "no handler" error (vs. silent / vs. crash)?

After reporting, click **Stop** in Scripts and Add-Ins (the script's
`stop()` cleans up).

---

## Phase E — Full add-in E2E (~30 min)

This is the moneyshot: install the production add-in, use it
naturally for ~5 minutes of CAD work, then lock the chain. If all the
probes passed, this should just work.

### Step E1 — Make sure the production add-in is loaded

In Scripts and Add-Ins, scroll to **ScrupleFusion** (under Add-Ins).
Click **Run**.

**Expect:** The Scruple palette is mounted with your API key still
remembered from Phase C.

### Step E2 — Create a test design + bind a project

1. **File → New Design**.
2. Sketch on XY plane → draw a rectangle → extrude it 10 mm.
3. **Cmd+S / Ctrl+S** to save. Name it `scruple-e2e-test`.
4. In the Scruple palette, click **Witness now**.
   - The palette's iteration counter should tick to **1**.
   - A new project should appear in the picker dropdown
     (auto-named after your design).

### Step E3 — Five iterations

For each of these, make a real change to the design (extrude another
feature, fillet an edge, change a parameter), then save (Cmd+S):

1. Extrude a hole through the center.
2. Fillet one edge.
3. Add a chamfer to another edge.
4. Change the extrude height parameter.
5. Add a second body somewhere.

After each save:
- Palette iteration counter increments.
- "Recent leaves" list at the bottom shows a new entry with a
  16-character leaf hash prefix.

**Expect:** Counter shows **6** total (the initial witness from E2
plus 5 saves). All leaf hashes are distinct.

### Step E4 — Verify on scruple-web

On your desktop, open in browser:
```
https://scruple.stooges.ai/projects
```

Sign in via Google as `test@scruple.dev` (or use the dev session
backdoor — same as Phase A3 but in browser). You should see your
`scruple-e2e-test` project in the list with 6 iterations.

### Step E5 — Lock & Anchor

In the Scruple palette, click **Lock & Anchor**.

**Expect:**
- Palette transitions to "Locking…" busy state.
- Your default system browser opens to a Stripe Checkout page
  (sandbox / test mode — no real charge).
- After payment in browser (Stripe test card `4242 4242 4242 4242`,
  any future expiry, any CVC), the browser returns to scruple.ai.
- Back in Fusion, the palette refreshes after ~5-10 seconds and
  shows: `Locked: SCR_XXXXXXXX` with a "View receipt" link.
- The Fusion document's **Attributes** are populated. Check via
  Inspect (Cmd+I → "Attributes" tab if available; or close + reopen
  the document and re-run **Witness now** — the palette should pull
  the existing project_id instead of creating a new one).

### Step E6 — Verify the receipt

In your desktop browser, navigate to the URL the palette shows. Or:

```
https://scruple.stooges.ai/receipt/SCR_XXXXXXXX
```

**Expect:**
- Page renders with: project name, 6 iterations listed, merkle root,
  RVN testnet txid (proofTxId), IPFS CID, arlocal arweaveTxId,
  Stripe payment marker.
- Receipt is shareable / printable.

### Step E7 — Close + reopen test

1. Close the Fusion document (don't quit Fusion).
2. Reopen it from Fusion Team / Recent.
3. In the Scruple palette, click **Witness now** — the palette
   should land on the SAME project, NOT create a new one. The
   iteration counter should be 7 after this.

This confirms the per-document binding via `design.attributes`
survives close + reopen.

---

## Phase F — Reporting

Send back:

1. A short markdown table:

```
| Probe | Result | Notes |
|---|---|---|
| 5.1  | PASS/FAIL/PARTIAL | … |
| 5.2  | … | … |
| 5.3  | … | … |
| 5.4  | … | … |
| 5.5  | … | … |
| 5.6  | … | … |
| E2E  | … | SCR-ID if locked |
```

2. Verbatim console output for any FAIL/PARTIAL.

3. Screenshots of:
   - The Scruple palette in its initial state (after API key entry).
   - The Scruple palette after E3 (iteration counter at 6).
   - The Scruple panel from Probe 5.6 (if it appeared).
   - The locked-state palette from E5 (showing SCR-ID).
   - Any error dialogs Fusion threw.

4. Your environment:
   - Fusion version (top-right menu → About).
   - OS + version.
   - Network setup (direct? SSH tunnel? VPN?).

5. **Time spent.** This helps us calibrate the probe time estimates.

---

## Triage matrix

If probe X fails, here's what it means + what we do next:

| Probe | Failure means | Fallback / next step |
|---|---|---|
| 5.1 (ExportManager) | Export blocks on a dialog or doesn't work on linked subassemblies | Add a "Pack & Go" path for multi-doc; flag for follow-up |
| 5.2 (documentSaved) | Recovery autosave fires the event | Add a dedupe filter (ignore events <60s apart from same hash) |
| 5.3 (Background thread) | Fusion freezes/crashes on bg-thread API call | Already designed around — `auto_witness.py` marshals via fireCustomEvent. Just confirms that path is mandatory |
| 5.4 (Palette React UI) | WebEngine can't render React | **Hard blocker** — fall back to Option 3 (native HTML palette, +~1 week) |
| 5.5 (Browser handoff) | System browser doesn't open OR local listener never fires | If browser opens but scheme handler missing → ship without the polished scheme, use local listener only. If browser doesn't open at all → block. |
| 5.6 (UI button registration) | Panel doesn't appear OR Fusion crashes | Drop the panel, rely on palette-only UI for v1 |

---

## Common failure remedies

### "Palette is blank / white"
- The React bundle didn't load. Open the embedded Chromium devtools
  if Fusion's version supports it (Help → Diagnose → Web Inspector
  on some versions). Check console for errors.
- Most likely cause: API key URL param missing or wrong.

### "Bearer token rejected with 401"
- Token was revoked OR didn't transmit. Re-issue per Step A3.
- Check that you copied the FULL string starting with `sk_test_`.

### "Witness now does nothing"
- The palette → Python bridge isn't connected. Open TEXT COMMANDS
  and look for errors when you click. The bridge is set up via
  `window.adsk.fusionSendData` — older Fusion builds may not expose
  it; check version.

### "Lock & Anchor → Stripe never opens"
- The custom URL scheme isn't registered. Check the palette UI —
  there should be a fallback "Pay manually" link with the Stripe URL
  you can paste into a browser.

### "Receipt page shows 'project not found'"
- Likely cause: the lock landed under a different user_id. This is
  a regression on the auth layer; flag immediately with the SCR-ID.

---

## Optional — Long-soak test (run overnight)

If you want to stress-test the auto-witness loop:

1. Open a Fusion design.
2. Set the palette's interval to 1 minute (Settings dialog →
   "Auto-witness every N minutes"). (Settings dialog ships in v0.2;
   for v0.1 the default is 5 min.)
3. Leave Fusion running for 8 hours with the design open.
4. Periodically make small edits + saves.
5. Next morning: verify the palette shows ~480 leaves (one per
   minute) plus however many explicit saves.

This catches: thread leaks, memory growth, witness server backpressure
under sustained load.

---

## Where this plan came from

Generated 2026-06-30 by the Oracle-side build session after Phases
0-4 + Z landed (21 / 21 automated tests green, including one full
chain-lock E2E producing `SCR_35FF0AD9`). See
`SESSION_REPORT_2026-06-30.md` for what's in scope vs. what awaits
this desktop validation.
