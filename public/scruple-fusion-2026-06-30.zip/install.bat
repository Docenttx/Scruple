@echo off
REM install.bat - copy ScrupleFusion into Fusion 360's AddIns directory (Windows).

setlocal
set "SRC_DIR=%~dp0"
set "ADDIN_DIR=%APPDATA%\Autodesk\Autodesk Fusion 360\API\AddIns\ScrupleFusion"

echo Copying %SRC_DIR% to %ADDIN_DIR%
if not exist "%ADDIN_DIR%" mkdir "%ADDIN_DIR%"

robocopy "%SRC_DIR%" "%ADDIN_DIR%" /MIR /XD __pycache__ .pytest_cache .venv tests palette_dev .git node_modules /NJH /NJS /NDL /NC /NS

echo.
echo Installed. To complete setup:
echo.
echo   1. Open Fusion 360
echo   2. Utilities ^> Scripts and Add-Ins (or Shift+S)
echo   3. Add-Ins tab ^> ScrupleFusion ^> Run
echo   4. The Scruple palette should dock on the right
echo   5. Paste your API key from scruple.ai - Account - API Keys
echo.
endlocal
