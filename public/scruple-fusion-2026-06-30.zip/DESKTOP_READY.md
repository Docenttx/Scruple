# Desktop test — ready to go

Everything server-side is staged. Open this file on your **desktop**
(Mac or Windows) and walk through it top to bottom. When you hit
**Step 4**, that's when you open Fusion 360.

**Generated:** 2026-06-30
**Server URL:** `https://scruple.stooges.ai` (same Cloudflare tunnel the
ComfyUI canvas already uses — known-good infra)
**scruple-web branch:** `feature/pivot` (commit `5dd6c0a` + UA fix)
**scruple-fusion repo:** `master` (commit `4c9079d` + UA fix)

---

## Status board (verified just now)

| Service                       | URL                                         | Status |
|---|---|---|
| scruple-web                   | https://scruple.stooges.ai/api/health       | ✓ 200 |
| Embed page                    | https://scruple.stooges.ai/embed/fusion     | ✓ renders palette markup |
| Bearer auth                   | GET /api/projects                           | ✓ 200 |
| `/api/witness/cad`            | POST                                        | ✓ wired |
| `/api/lock/chain`             | POST                                        | ✓ wired (3-anchor lock proven) |
| RVN testnet + IPFS + Arweave  | (via witness server)                        | ✓ all three anchored this session |
| Live test sweep               | 21 / 21 pytest against public URL           | ✓ green |

---

## Your test session API key

```
sk_test_DvsZa2X0OoIc5HH9TQO_3WABpQLpxS_azCOHVfwVstA
```

- **Label:** `desktop-fusion-2026-06-30`
- **Key ID:** `93f909a5-53c6-4072-a19b-a49558e6e517`
- **User:** `test@scruple.dev` (dev user — same one canvas testing uses)
- **Expires:** never

Saved on Oracle at `/data/scruple-fusion/.desktop-api-key` if you need
to re-pull it. Don't commit it.

---

## Step 1 — Pull the add-in to your desktop (~1 min)

```bash
mkdir -p ~/scruple-fusion
rsync -av --exclude='__pycache__' --exclude='.pytest_cache' \
  --exclude='.git' --exclude='.desktop-*' \
  ubuntu@129.80.23.93:/data/scruple-fusion/ ~/scruple-fusion/
```

(Or substitute your usual oracle host alias.)

**No SSH tunnel needed.** The add-in talks directly to
`https://scruple.stooges.ai` — same path canvas already uses for ComfyUI.

---

## Step 2 — Run the desktop precheck (~10 sec)

This validates the public URL is reachable + your API key works +
all the add-in routes are wired. Run before opening Fusion.

```bash
cd ~/scruple-fusion
chmod +x desktop-precheck.sh
./desktop-precheck.sh "sk_test_DvsZa2X0OoIc5HH9TQO_3WABpQLpxS_azCOHVfwVstA"
```

You should see **5 green checks**. If any are red, the script tells
you what to fix.

---

## Step 3 — Install the add-in into Fusion 360

**Mac:**
```bash
cd ~/scruple-fusion
./install.sh --link
```

**Windows (PowerShell):**
```powershell
cd $HOME\scruple-fusion
.\install.bat
```

---

## Step 4 — NOW open Fusion 360

1. Open Fusion 360.
2. **Shift+S** (or Utilities → Scripts and Add-Ins).
3. **Add-Ins** tab → **ScrupleFusion** → **Run**.
4. The Scruple palette docks on the right.
5. Paste the API key (above) into the password field. Press Enter.

The palette should populate with your project list (it'll show
whatever's under `test@scruple.dev` — should be ~30 test projects
from the build sessions).

From here, pick up at **Phase C** in `DESKTOP_TEST_PLAN.md` for the
6-probe sequence + the full E2E lock walkthrough.

---

## What changed from the earlier draft (FYI)

Previously this doc said to set up an SSH tunnel. We switched to the
public Cloudflare tunnel (`scruple.stooges.ai`) because:

1. The infra is already running for the ComfyUI canvas (`canvas.stooges.ai`
   uses the same tunnel) — known-good.
2. Real HTTPS instead of `localhost:3001` means Fusion's embedded
   Chromium is more likely to render the React palette cleanly (Probe
   5.4 should pass on the first try).
3. Stripe Checkout redirects work without `localhost` hacks.
4. No second terminal, no tunnel babysitting.

**Caveat:** the server-side process behind `scruple.stooges.ai` is
currently `next dev` (not `next start`). Functionally identical, just
slower on first-hit compile per route. For a real public launch we'd
swap to `next start` after `npm run build`. Doesn't affect this test.

---

## If something breaks server-side mid-test

These commands run on Oracle (ssh in first):

```bash
# Refund arlocal if it ran dry:
curl "http://localhost:1984/mint/TLhGT92H-quX2nrNt2dPWxr4fCfLw8fleRJPb4mBCHo/1000000000000000"
curl "http://localhost:1984/mine"

# Restart scruple-web dev process:
pkill -f "next dev"
cd /data/scruple-web && PORT=3001 nohup npm run dev > /tmp/scruple-web-dev.log 2>&1 &

# Re-issue API key if needed:
SECRET="662651ecc4f1375d82496ca505720bf123b9a67c9a0f38c5"
TOKEN=$(curl -s "http://localhost:3001/api/dev/session?email=test@scruple.dev&secret=$SECRET" \
  | python3 -c 'import json,sys; print(json.load(sys.stdin)["sessionToken"])')
curl -s -X POST -H "Cookie: __Secure-authjs.session-token=$TOKEN" \
  -H "Content-Type: application/json" -d '{"label":"desktop-fusion-redo"}' \
  http://localhost:3001/api/auth/keys
```

The `plaintext` field is your new key.

---

## When you're done

1. Send back the **Phase F report** from `DESKTOP_TEST_PLAN.md`.
2. Optional: revoke the test API key:
   ```bash
   curl -s -X DELETE \
     -H "Authorization: Bearer sk_test_DvsZa2X0OoIc5HH9TQO_3WABpQLpxS_azCOHVfwVstA" \
     https://scruple.stooges.ai/api/auth/keys/93f909a5-53c6-4072-a19b-a49558e6e517
   ```
   Or leave it — `test@scruple.dev` is the dev user.
