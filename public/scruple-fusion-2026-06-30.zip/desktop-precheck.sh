#!/usr/bin/env bash
# desktop-precheck.sh — validate the desktop can reach scruple-web before
# opening Fusion 360.
#
# Default target is the public Cloudflare tunnel: https://scruple.stooges.ai
# (same infra the ComfyUI canvas at canvas.stooges.ai uses). No SSH tunnel
# required; everything goes over real HTTPS.
#
# Usage:  ./desktop-precheck.sh <API_KEY> [BASE_URL]
#
# Runs 5 checks:
#   1. Server reachable                  (GET /api/health → 200)
#   2. API key authenticates             (Bearer GET /api/projects → 200)
#   3. /embed/fusion serves with token   (HTML contains palette markup)
#   4. /api/witness/cad route wired      (POST {} returns 401 or 400, not 404)
#   5. /api/lock/chain route wired       (same probe pattern)
#
# Exits 0 if all pass, 1 otherwise.

set -u

API_KEY="${1:-}"
BASE="${2:-${SCRUPLE_BASE:-https://scruple.stooges.ai}}"

if [[ -z "$API_KEY" ]]; then
  echo "Usage: $0 <API_KEY> [BASE_URL]"
  echo "Example: $0 sk_test_…"
  echo "         $0 sk_test_… http://localhost:3001    # if you have a tunnel"
  exit 2
fi

red()   { printf "\033[31m%s\033[0m" "$1"; }
green() { printf "\033[32m%s\033[0m" "$1"; }
bold()  { printf "\033[1m%s\033[0m"  "$1"; }

UA="scruple-fusion-precheck/0.1.0 (+https://scruple.ai)"
CURL_BASE=(curl -sS --max-time 10 -A "$UA")

pass=0
fail=0

check() {
  local label="$1"; local detail="$2"; local result="$3"
  if [[ "$result" = "0" ]]; then
    printf "  [%s] %s\n" "$(green '✓')" "$label"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    pass=$((pass+1))
  else
    printf "  [%s] %s\n" "$(red '✗')" "$label"
    [[ -n "$detail" ]] && printf "       %s\n" "$detail"
    fail=$((fail+1))
  fi
}

bold "Scruple Fusion desktop precheck"; echo ""
echo "  Target:  $BASE"
echo "  Key:     ${API_KEY:0:14}…"
echo ""

# 1. Server reachable
code=$("${CURL_BASE[@]}" -o /dev/null -w "%{http_code}" "$BASE/api/health" 2>/dev/null)
if [[ "$code" = "200" ]]; then
  check "Server reachable" "HTTP $code from $BASE/api/health" 0
else
  check "Server reachable" "HTTP $code — is $BASE up? (check connectivity)" 1
fi

# 2. API key authenticates
code=$("${CURL_BASE[@]}" -o /tmp/.precheck_projects.json -w "%{http_code}" \
  -H "Authorization: Bearer $API_KEY" "$BASE/api/projects" 2>/dev/null)
if [[ "$code" = "200" ]]; then
  count=$(python3 -c 'import json; d=json.load(open("/tmp/.precheck_projects.json")); print(d.get("count","?"))' 2>/dev/null)
  check "API key authenticates" "HTTP 200, you have $count visible projects" 0
elif [[ "$code" = "401" ]]; then
  check "API key authenticates" "HTTP 401 — key invalid or revoked. Re-mint per DESKTOP_READY.md" 1
elif [[ "$code" = "403" ]]; then
  check "API key authenticates" "HTTP 403 — Cloudflare blocked the request. Check User-Agent" 1
else
  check "API key authenticates" "HTTP $code — unexpected" 1
fi

# 3. /embed/fusion serves
code=$("${CURL_BASE[@]}" -o /tmp/.precheck_embed.html -w "%{http_code}" \
  "$BASE/embed/fusion?token=$API_KEY&project_id=1" 2>/dev/null)
if [[ "$code" = "200" ]]; then
  size=$(wc -c < /tmp/.precheck_embed.html | tr -d ' ')
  if grep -q "FusionPalette\|Scruple for Fusion" /tmp/.precheck_embed.html 2>/dev/null; then
    check "Embed page renders" "HTTP 200, $size bytes, palette markup detected" 0
  else
    check "Embed page renders" "HTTP 200 but palette markup MISSING — investigate" 1
  fi
else
  check "Embed page renders" "HTTP $code from $BASE/embed/fusion" 1
fi

# 4. /api/witness/cad route exists
code=$("${CURL_BASE[@]}" -o /dev/null -w "%{http_code}" \
  -X POST -H "Content-Type: application/json" -d '{}' \
  "$BASE/api/witness/cad" 2>/dev/null)
if [[ "$code" = "401" || "$code" = "400" ]]; then
  check "/api/witness/cad route wired" "HTTP $code (expected — auth gate or bad-body)" 0
elif [[ "$code" = "404" ]]; then
  check "/api/witness/cad route wired" "HTTP 404 — scruple-web doesn't have this route. Check the deploy" 1
else
  check "/api/witness/cad route wired" "HTTP $code — unexpected" 1
fi

# 5. /api/lock/chain route exists
code=$("${CURL_BASE[@]}" -o /dev/null -w "%{http_code}" \
  -X POST -H "Content-Type: application/json" -d '{}' \
  "$BASE/api/lock/chain" 2>/dev/null)
if [[ "$code" = "401" || "$code" = "400" ]]; then
  check "/api/lock/chain route wired" "HTTP $code (expected — auth gate or bad-body)" 0
elif [[ "$code" = "404" ]]; then
  check "/api/lock/chain route wired" "HTTP 404 — scruple-web doesn't have this route" 1
else
  check "/api/lock/chain route wired" "HTTP $code — unexpected" 1
fi

rm -f /tmp/.precheck_projects.json /tmp/.precheck_embed.html 2>/dev/null

echo ""
if [[ "$fail" = "0" ]]; then
  bold "All $pass / $((pass+fail)) checks passed."
  echo ""
  echo "You're cleared to open Fusion 360."
  echo "Next:  cat DESKTOP_TEST_PLAN.md   # pick up at Phase C"
  exit 0
else
  bold "$fail / $((pass+fail)) checks FAILED."
  echo ""
  echo "Don't open Fusion 360 yet. Fix the failing checks above first."
  echo "See DESKTOP_READY.md → 'If something breaks server-side mid-test'."
  exit 1
fi
