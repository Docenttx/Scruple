# Scruple for Fusion 360 — Website Section Draft

For the scruple.ai site. Tone matches the existing Website v1 brief: institutional, technical, restrained. Can become its own page (`/fusion`) or sit as a section under `/use-cases` / `/studio`.

---

## Hero

**Scruple for Fusion 360**

Cryptographic provenance for your design work — running quietly inside Fusion, locked when you're ready.

---

## What it does

One paragraph, prominent.

> Scruple for Fusion 360 captures every save and every working interval as a cryptographic record. When you've finished the design — or hit a milestone worth attesting — one click locks the entire chain to a public ledger. The lock is permanent, court-ready, and verifiable by any third party without needing you, Autodesk, or Scruple.

---

## How a Fusion session works

Three numbered moments — designer can render as a stepped diagram or three numbered cards.

1. **You install Scruple from the Fusion add-in store.** A small panel appears docked to the right of your modeling view.
2. **You model normally.** Scruple watches in the background. Every save is silently captured. Every five minutes (configurable) — if you've changed anything — a fresh snapshot enters the chain. The panel shows the count growing as you work.
3. **You click Lock.** The entire chain is committed to the public ledger as a single tamper-evident receipt. You get a SCR-ID and a verification URL that anyone can check.

---

## What gets bound into the lock

Designer: render as a clean list, like the Studio page's receipt-fields visual.

- **Every captured snapshot** — the full Fusion archive bytes, hashed
- **The toolchain identity** — Fusion version, your machine context
- **Per-snapshot chain link** — each capture cryptographically references the previous one
- **Merkle commitment** — a single root over the entire session's chain
- **Three independent ledger anchors** — Ravencoin testnet, IPFS, Arweave

The exact same receipt format you get from Scruple Studio applies. The same open verification tool checks both.

---

## What you keep, what we don't

A small reassurance box, important for engineering firms and IP-conscious users.

- Your design stays in Autodesk Fusion and Fusion Team. We don't replicate it.
- Scruple holds **only cryptographic commitments** to your work — hashes and signatures, never your geometry.
- The snapshots Scruple takes during witnessing are retained on the public ledger anchors *only as hashes*, never as files.
- If you want to retain the file bytes themselves, that's your choice — Scruple gives you the receipt; you keep the design.

---

## What this is good for

Designer: render as three short case rows, similar to the Use Cases page structure.

**Patent prosecution and IP litigation.**
A datable, court-admissible record of when a design existed in a specific state, anchored to a public ledger no party controls. Useful for prior-art establishment, invention dates, and infringement disputes.

**Regulated design environments.**
Aerospace, medical device, automotive — anywhere the audit trail of *how* a part reached its final geometry has to be reproducible and trustworthy. Scruple captures the chain; your existing PLM keeps the files.

**Design service firms.**
Prove to a client that the work delivered is the work that was actually done, on the dates billed. No more "did you really design this for us, or was it AI-generated?" disputes.

---

## How verification works

Same as everything else Scruple does — third-party verifiable, no proprietary tools required.

1. Anyone with the SCR-ID can fetch the public receipt at `scruple.ai/receipt/<scr_id>`.
2. The open audit tool re-derives every chain link from first principles using the receipt and public ledger data.
3. The Merkle commitment on Ravencoin testifies to a single moment in time, signed by the public ledger itself.

No download of Fusion required for verification. No subscription. No call to Scruple's servers. The receipt and the public ledger are sufficient.

---

## Status

- **Public beta:** target date TBD (see release schedule)
- **Pilot access available now** for firms with concrete legal-evidentiary or regulated-design use cases. Pilot includes direct support during integration with your existing IP / PLM workflow.

## CTA

**Request pilot access** — goes to the standard gated form, routes by interest.

---

## Designer notes (not for public copy)

- Keep the tone aligned with the Standard / Studio pages: institutional, no exclamation points, no AI-marketing language ("revolutionary," "powered by"), no claims past the boundary.
- The "court-ready" framing is the same FRE 902 / self-authenticating angle used across the rest of the site — keep it consistent.
- Eventually the page wants a screenshot of the Fusion palette docked, showing the live witness counter and recent leaves — designer to request when add-in MVP is rendering.
- No pricing on first launch. CTA is pilot access only.

---

## Companion materials (Drive)

- Build plan: `Scruple Fusion Add-In — Build Plan (2026-06-29)` in DevSpaceManual/Scruple
- Patent Delta segments 01-05 + critique (relevant for the claim-boundary copy)
- Website v1 series — match the existing tone
