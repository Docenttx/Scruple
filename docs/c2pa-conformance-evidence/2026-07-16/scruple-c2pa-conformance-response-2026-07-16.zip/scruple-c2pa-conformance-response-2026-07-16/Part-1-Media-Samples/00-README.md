# Part 1 — Media-Type Evidence Bundle

This part answers Asks 1, 2, and 3 in the reviewer's email. Every
asserted MIME from the Intake Form has a corresponding folder.

## Folder naming convention

- `Generate.output.<mediatype>/` — a signed sample per asserted
  generate MIME, plus the extracted C2PA manifest as JSON (Ask 1).
- `Raw.input.<mediatype>/` — an unsigned sample per asserted
  validate MIME (Ask 2).
- `Validate.output.<mediatype>/` — a signed sample produced after
  ingesting the matching raw input. The ingested manifest becomes an
  ingredient in the fresh output (Ask 3).

## Coverage summary

| Aspect | Asserted MIMEs | Covered | Signed | Documented gap |
|---|---|---|---|---|
| Generate | 16 | 16 | 15 | 1 (`application/x-pytorch`) |
| Raw input | 20 | 20 | n/a | 0 |
| Validate output | 20 | 20 | 18 | 2 (`application/pdf`, `application/x-pytorch`) |

The three gaps share one cause: the `c2pa-python` wrapper used by
the bundle producer does not yet expose signing for those MIMEs.
Each affected folder contains a `NOT_SUPPORTED.txt`.

## Verification

Every signed sample verifies as `validation_state = Valid` via any
C2PA v2.x reader against the dev cert chain in `certificates/`.

## Machine-readable manifest

`_bundle_report.json` describes every folder, its media file, its
JSON manifest, the SHA-256 of each, and the signing status.
