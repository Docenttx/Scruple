# Part 2 — Generator Product Security Architecture

Assurance level sought: **Level 2**, with implicit Level 1.

## Contents

- `01-GPSA.md` — the Generator Product Security Architecture Document,
  structured to match Appendix C of the C2PA Generator Product
  Security Requirements v0.1 (2025-06-02).
- `evidence/architecture-diagram.md` — black-box view of trust
  boundaries and authentication paths, referenced from §C.1.4 of
  the GPSA.
- `evidence/l2-evidence-2026-07-12T174954Z/` — first hardware
  Root-of-Trust attestation bundle.
- `evidence/l2-evidence-2026-07-15T132856Z/` — second, independently
  produced attestation bundle. Byte-identical VM measurement to the
  first bundle, demonstrating reproducible boot image.

## Per-objective status (self-assessed, Level 2)

| Objective | Section | Status |
|---|---|---|
| O.1 Certificate enrollment (§6.1) | C.2.1 | N/A — Trust List CA enrollment is manual by design |
| O.2 Key management (§6.2) | C.2.2 | **L2 satisfied.** Key non-extractable in a hardware-attested TEE; two independent attestation bundles attached |
| O.3 Claim Generator protections (§6.3) | C.2.3 | **L2 satisfied.** SCA, SAST, SBOM, reproducible build, TEE-pinned patch recency |
| O.4 Content processing (§6.4) | C.2.4 | **L2 satisfied.** Same CI coverage; Signer isolation |
| O.5 Traffic protections (§6.5) | C.2.5 | **L2 satisfied.** TLS 1.3 external; mTLS 1.3 internal with per-request seal |
| O.6 Hosting environment (§6.6) | C.2.6 | **L2 satisfied.** Cloud IAM RBAC; audit logging; HIDS; network segmentation |

## Vulnerability disclosure

The public Scruple repository contains a `SECURITY.md` documenting
the coordinated-disclosure process, contact address
(`scruple@docentechs.com`), triage SLA (48 hours), and remediation
timelines: 30 days for high-severity CVSS, 90 days for moderate,
180 days for low, per the Requirements Document footnote.

## Fallback grading

Where L2 evidence is insufficient in the assessor's judgment for a
specific objective, Scruple accepts grading at L1 for that
objective with no architectural change.
