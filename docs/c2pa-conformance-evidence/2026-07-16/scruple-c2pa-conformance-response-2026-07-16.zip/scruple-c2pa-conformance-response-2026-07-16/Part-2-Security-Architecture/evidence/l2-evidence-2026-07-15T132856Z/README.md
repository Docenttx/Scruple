# L2 Evidence Bundle — 2026-07-15

Second, independently produced Hardware Root-of-Trust attestation
binding a fresh C2PA signing key to a freshly provisioned attested
TEE. The VM measurement in this report is byte-for-byte identical
to the 2026-07-12 bundle, demonstrating that the Signer boot image
is reproducible.

## Files

| File | Description |
|---|---|
| `sev-snp-report.bin` | AMD SEV-SNP attestation report (ABI v5) |
| `vcek.der` | AMD-issued Versioned Chip Endorsement Key |
| `ark.pem` | AMD Root Key certificate |
| `ask.pem` | AMD Signing Key certificate |
| `scruple-c2pa-pubkey.der` | HSM ES256 public key (SPKI DER) |
| `scruple-c2pa-pubkey.pem` | Same public key in PEM form |
| `scruple-c2pa-pubkey.sha256` | SHA-256 of the DER public key |
| `report-summary.txt` | Human-readable dump of the attestation report |
| `MANIFEST.sha256` | Manifest of shipped-file SHA-256s |

## The binding

Same as the 2026-07-12 bundle: the SHA-256 of
`scruple-c2pa-pubkey.der` appears as the first 32 bytes of the
attestation report's `report_data` field, proving key possession by
the attested TEE.

## Independent verification

Same procedure as the 2026-07-12 bundle. The AMD chain here is
provided as `ark.pem` and `ask.pem` (separately) rather than a
concatenated chain PEM; combine as needed for your verifier.

## Reproducibility of the Signer boot image

The report's VM measurement is identical to the 2026-07-12 report's
VM measurement, notwithstanding that the two attestations were
generated from independent TEE launches on different dates against
different HSM keys. This demonstrates that the boot image is
reproducible.
