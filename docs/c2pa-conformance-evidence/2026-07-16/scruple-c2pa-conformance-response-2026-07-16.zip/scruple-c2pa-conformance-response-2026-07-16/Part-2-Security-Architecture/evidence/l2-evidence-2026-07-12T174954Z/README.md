# L2 Evidence Bundle — 2026-07-12

Hardware Root-of-Trust attestation binding the C2PA signing key to
the attested Trusted Execution Environment. Satisfies C2PA GPSR
§6.2.2 L2(d)(i).

## Files

| File | Description |
|---|---|
| `sev-snp-report.bin` | AMD SEV-SNP attestation report (ABI v5) |
| `vcek.der` | AMD-issued Versioned Chip Endorsement Key |
| `amd-cert-chain.pem` | AMD Root Key → Signing Key chain |
| `scruple-c2pa-pubkey.der` | HSM ES256 public key (SPKI DER) |
| `scruple-c2pa-pubkey.pem` | Same public key in PEM form |
| `scruple-c2pa-pubkey.sha256` | SHA-256 of the DER public key |
| `MANIFEST.sha256` | Manifest of shipped-file SHA-256s |

## The binding

The 32-byte SHA-256 of `scruple-c2pa-pubkey.der` appears as the
first 32 bytes of the attestation report's `report_data` field
(64 bytes; the remaining 32 are zero-padding). This proves the
specific ES256 key was in the possession of the attested TEE at
the moment the report was issued.

## Independent verification

Any verifier holding this bundle can, without Scruple's cooperation:

1. Verify the AMD certificate chain
   (`amd-cert-chain.pem` → `vcek.der`) against AMD's public root at
   `https://kdsintf.amd.com/vcek/v1/Genoa/`.
2. Verify `vcek.der` signed the report body inside `sev-snp-report.bin`.
3. Extract the `report_data` field from the report.
4. Compute SHA-256 of `scruple-c2pa-pubkey.der` and compare against
   the first 32 bytes of `report_data`.

All four steps succeed byte-for-byte.
