# Scruple C2PA Conformance Program Response

**Intake record ID:** `019f5856-bff8-7f57-a879-80594a6fb3fe`
**Filed by:** Docent LLC (dba Scruple)
**Date:** 2026-07-16
**Assurance level sought:** Level 2, with implicit Level 1

---

Read `01-cover-letter.md` first. It maps every item in the reviewer's
evidence request to its location in this zip and is byte-identical
to the body of the email that delivered this zip.

## Layout

```
scruple-c2pa-conformance-response-2026-07-16/
├── 00-README-START-HERE.md
├── 01-cover-letter.md
│
├── Part-1-Media-Samples/              (Asks 1, 2, 3)
│   ├── 00-README.md
│   ├── README.md
│   ├── _bundle_report.json
│   ├── certificates/
│   ├── Generate.output.<mediatype>/   (16 folders)
│   ├── Raw.input.<mediatype>/         (20 folders)
│   └── Validate.output.<mediatype>/   (20 folders)
│
└── Part-2-Security-Architecture/      (Asks 4, 5)
    ├── 00-README.md
    ├── 01-GPSA.md
    └── evidence/
        ├── architecture-diagram.md
        ├── l2-evidence-2026-07-12T174954Z/
        └── l2-evidence-2026-07-15T132856Z/
```

## Index by ask

| Reviewer asked for | Location |
|---|---|
| `Generate.output.<mediatype>/` | `Part-1-Media-Samples/Generate.output.*/` |
| `Raw.input.<mediatype>/` | `Part-1-Media-Samples/Raw.input.*/` |
| `Validate.output.<mediatype>/` | `Part-1-Media-Samples/Validate.output.*/` |
| Signature verification cert chain | `Part-1-Media-Samples/certificates/` |
| Assurance level declaration + not-capture-only confirmation | Cover letter §Confirmations |
| Generator Product Security Architecture Document | `Part-2-Security-Architecture/01-GPSA.md` |
| Hardware Root-of-Trust attestation evidence | `Part-2-Security-Architecture/evidence/l2-evidence-*/` |
